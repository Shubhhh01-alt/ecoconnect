import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { NotificationToast } from './components/NotificationToast';
import { Home } from './pages/Home';
import { TreePlantation } from './pages/TreePlantation';
import { FoodRescue } from './pages/FoodRescue';
import { WaterConservation } from './pages/WaterConservation';
import { CleanUp } from './pages/CleanUp';
import { ReportIssue } from './pages/ReportIssue';
import { Events } from './pages/Events';
import { ImpactDashboard } from './pages/ImpactDashboard';
import { Community } from './pages/Community';
import { About } from './pages/About';
import { Contact } from './pages/Contact';

// Scroll to top on route change
function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

export const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 transition-colors duration-200">
      <ScrollToTop />
      <Navbar />

      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/initiatives/tree-plantation" element={<TreePlantation />} />
          <Route path="/initiatives/food-rescue" element={<FoodRescue />} />
          <Route path="/initiatives/water-conservation" element={<WaterConservation />} />
          <Route path="/initiatives/clean-up" element={<CleanUp />} />
          <Route path="/report" element={<ReportIssue />} />
          <Route path="/events" element={<Events />} />
          <Route path="/impact" element={<ImpactDashboard />} />
          <Route path="/community" element={<Community />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </main>

      <Footer />
      <NotificationToast />
    </div>
  );
};

export default App;
