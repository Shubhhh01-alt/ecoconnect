import React, { useState } from 'react';
import { 
  Trees, 
  Sprout, 
  Heart, 
  MapPin, 
  Sparkles, 
  Award, 
  CheckCircle2, 
  Calendar, 
  Leaf, 
  Info, 
  Wind, 
  Droplet 
} from 'lucide-react';
import { useEco } from '../context/EcoContext';

const nativeSpeciesList = [
  {
    name: 'Neem',
    scientific: 'Azadirachta indica',
    co2Kg: 24,
    waterNeed: 'Low',
    growthRate: 'Fast (1-2m/yr)',
    benefits: 'Natural insecticide, oxygen powerhouse, extreme drought resilience',
    icon: '🌿'
  },
  {
    name: 'Sacred Fig (Peepal)',
    scientific: 'Ficus religiosa',
    co2Kg: 35,
    waterNeed: 'Low-Medium',
    growthRate: 'Moderate',
    benefits: '24-hour oxygen generator, heavy carbon sink, avian shelter',
    icon: '🌳'
  },
  {
    name: 'Indian Teak',
    scientific: 'Tectona grandis',
    co2Kg: 28,
    waterNeed: 'Moderate',
    growthRate: 'Moderate',
    benefits: 'Deep root network for soil erosion defense, long-lived hardwood',
    icon: '🌲'
  },
  {
    name: 'Jamun (Black Plum)',
    scientific: 'Syzygium cumini',
    co2Kg: 22,
    waterNeed: 'Medium',
    growthRate: 'Fast',
    benefits: 'Fruit-bearing canopy for biodiversity, rich pollinator attractant',
    icon: '🍇'
  },
  {
    name: 'Gulmohar (Flamboyant)',
    scientific: 'Delonix regia',
    co2Kg: 20,
    waterNeed: 'Low',
    growthRate: 'Very Fast',
    benefits: 'Broad urban cooling shade, vibrant scarlet nectar blooms',
    icon: '🌺'
  },
  {
    name: 'Drumstick (Moringa)',
    scientific: 'Moringa oleifera',
    co2Kg: 18,
    waterNeed: 'Minimal',
    growthRate: 'Rapid',
    benefits: 'Nutrient-rich leaves, rapid ground restoration, pollinator magnet',
    icon: '🌱'
  }
];

export const TreePlantation: React.FC = () => {
  const { treePledges, pledgeTree, currentUser } = useEco();

  const [selectedSpecies, setSelectedSpecies] = useState(nativeSpeciesList[0]);
  const [planterName, setPlanterName] = useState(currentUser.name);
  const [dedication, setDedication] = useState('');
  const [location, setLocation] = useState('Aravalli Biodiversity Corridor, Sector 54');
  const [pledgeSuccess, setPledgeSuccess] = useState(false);

  const handlePledgeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    pledgeTree({
      species: selectedSpecies.name,
      scientificName: selectedSpecies.scientific,
      plantedBy: planterName || 'Anonymous Eco-Warrior',
      location,
      co2PerYearKg: selectedSpecies.co2Kg,
      dedication: dedication.trim() || undefined,
      treeIcon: selectedSpecies.icon
    });
    setPledgeSuccess(true);
    setTimeout(() => setPledgeSuccess(false), 5000);
    setDedication('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* 1. Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-emerald-900 via-green-950 to-slate-900 border border-emerald-500/30 p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-4">
            <Trees className="w-4 h-4" /> UN SDG 15: Life on Land
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight mb-4 leading-tight">
            Native Tree Plantation & <br />
            <span className="text-emerald-400">Virtual Community Forest</span>
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            Pledge native biodiverse saplings for verified Miyawaki urban forest clusters. We partner with local nurseries and conservation trusts to plant, nurture, and geotag every single tree for a minimum 3-year survival cycle.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-emerald-800/60">
            <div>
              <div className="text-2xl sm:text-3xl font-black text-emerald-400">142,850+</div>
              <div className="text-xs text-slate-300">Trees Planted</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-black text-emerald-400">3,420+ Tons</div>
              <div className="text-xs text-slate-300">Lifetime CO2 Captured</div>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <div className="text-2xl sm:text-3xl font-black text-emerald-400">89.4%</div>
              <div className="text-xs text-slate-300">3-Year Survival Rate</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Interactive Pledge Form & Species Selector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form */}
        <div className="lg:col-span-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
          <div className="flex items-center gap-2.5 text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-2">
            <Sparkles className="w-4 h-4" /> Instant Pledge Generator
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">
            Pledge a Native Tree Today
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mb-6">
            Select a native species that matches your ecosystem. Earn 120 EcoPoints upon pledging.
          </p>

          {pledgeSuccess && (
            <div className="mb-6 p-4 rounded-2xl bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-500/40 text-emerald-900 dark:text-emerald-200 flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-500 flex-shrink-0" />
              <div>
                <div className="font-bold text-sm">Tree Pledged Successfully! (+120 EcoPoints)</div>
                <div className="text-xs">Your sapling has been added to our upcoming planting drive roster.</div>
              </div>
            </div>
          )}

          <form onSubmit={handlePledgeSubmit} className="space-y-5">
            {/* Species Selection Grid */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2">
                1. Select Native Species
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {nativeSpeciesList.map(species => (
                  <button
                    key={species.name}
                    type="button"
                    onClick={() => setSelectedSpecies(species)}
                    className={`p-3 rounded-2xl text-left border transition-all ${
                      selectedSpecies.name === species.name
                        ? 'bg-emerald-50 dark:bg-emerald-950/70 border-emerald-500 ring-2 ring-emerald-500/20'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                    }`}
                  >
                    <div className="text-2xl mb-1">{species.icon}</div>
                    <div className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white truncate">
                      {species.name}
                    </div>
                    <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                      ~{species.co2Kg} kg CO2/yr
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Planter Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                  Planter Name
                </label>
                <input
                  type="text"
                  value={planterName}
                  onChange={e => setPlanterName(e.target.value)}
                  required
                  placeholder="Your full name"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                  Planting Zone
                </label>
                <select
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Aravalli Biodiversity Corridor, Sector 54">Aravalli Biodiversity Corridor, Gurugram</option>
                  <option value="Yamuna Riverfront Micro-forest, Zone 7">Yamuna Riverfront Micro-forest, New Delhi</option>
                  <option value="Thane Mangrove & Coastal Buffer">Thane Mangrove & Coastal Buffer, Mumbai</option>
                  <option value="Sarjapur Urban Bio-reserve">Sarjapur Urban Bio-reserve, Bengaluru</option>
                </select>
              </div>
            </div>

            {/* Optional Dedication */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                Dedication Note (Optional)
              </label>
              <input
                type="text"
                value={dedication}
                onChange={e => setDedication(e.target.value)}
                placeholder="e.g. In loving memory of..., Celebrating my daughter's birthday"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Impact Calculation Preview */}
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-500/20 flex items-center justify-between">
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400">Estimated 20-Year Carbon Offset</div>
                <div className="text-lg font-black text-emerald-700 dark:text-emerald-300">
                  {selectedSpecies.co2Kg * 20} kg of CO2
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-500 dark:text-slate-400">Reward</div>
                <div className="text-sm font-bold text-amber-600 dark:text-amber-400">
                  +120 EcoPoints
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              <Sprout className="w-4 h-4" />
              <span>Plant & Dedicate {selectedSpecies.name}</span>
            </button>
          </form>
        </div>

        {/* Selected Species Spotlight */}
        <div className="lg:col-span-5 rounded-3xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6">
          <div className="text-center pb-6 border-b border-slate-200 dark:border-slate-800">
            <div className="w-20 h-20 mx-auto rounded-3xl bg-white dark:bg-slate-800 shadow-md flex items-center justify-center text-4xl mb-3">
              {selectedSpecies.icon}
            </div>
            <h3 className="text-2xl font-black text-slate-900 dark:text-white">
              {selectedSpecies.name}
            </h3>
            <p className="text-xs italic text-slate-500">
              {selectedSpecies.scientific}
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500 flex items-center gap-2">
                <Wind className="w-4 h-4 text-emerald-500" /> Carbon Capture
              </span>
              <span className="font-bold text-slate-800 dark:text-slate-200">
                ~{selectedSpecies.co2Kg} kg/year
              </span>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500 flex items-center gap-2">
                <Droplet className="w-4 h-4 text-sky-500" /> Water Requirement
              </span>
              <span className="font-bold text-slate-800 dark:text-slate-200">
                {selectedSpecies.waterNeed}
              </span>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500 flex items-center gap-2">
                <Leaf className="w-4 h-4 text-teal-500" /> Growth Rate
              </span>
              <span className="font-bold text-slate-800 dark:text-slate-200">
                {selectedSpecies.growthRate}
              </span>
            </div>

            <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Ecological Advantage
              </span>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {selectedSpecies.benefits}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Virtual Community Forest Showcase */}
      <div>
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
              Live Community Forest
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              Recently Pledged Trees
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Every card represents a living sapling cared for by our on-ground volunteers.
            </p>
          </div>
          <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mt-2 md:mt-0">
            Total {treePledges.length} community pledges logged
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {treePledges.map(tree => (
            <div
              key={tree.id}
              className="rounded-2xl p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-3xl">{tree.treeIcon}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                    {tree.date}
                  </span>
                </div>

                <h4 className="font-bold text-slate-900 dark:text-white text-base">
                  {tree.species}
                </h4>
                <div className="text-[11px] text-slate-400 italic mb-2">
                  {tree.scientificName}
                </div>

                {tree.dedication && (
                  <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-500/20 text-xs text-amber-900 dark:text-amber-200 italic mb-3">
                    "{tree.dedication}"
                  </div>
                )}

                <div className="text-xs text-slate-500 mb-1 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                  <span className="truncate">{tree.location}</span>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">By {tree.plantedBy}</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">
                  {tree.co2PerYearKg} kg CO2/yr
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
