import React, { useState } from 'react';
import { 
  Calendar, 
  MapPin, 
  Users, 
  Plus, 
  Clock, 
  Search, 
  CheckCircle2, 
  Filter, 
  Sparkles,
  Award,
  ArrowRight
} from 'lucide-react';
import { useEco } from '../context/EcoContext';
import { EventCategory, EcoEvent } from '../types';

export const Events: React.FC = () => {
  const { events, toggleEventRSVP, createEvent, currentUser } = useEco();

  // Filter states
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Host event modal state
  const [hostModalOpen, setHostModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<EventCategory>('cleanup');
  const [date, setDate] = useState('Saturday, Dec 12');
  const [time, setTime] = useState('07:00 AM - 10:30 AM');
  const [location, setLocation] = useState('');
  const [city, setCity] = useState('New Delhi');
  const [spotsTotal, setSpotsTotal] = useState(50);
  const [imageUrl, setImageUrl] = useState('https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80');

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description || !location) return;

    createEvent({
      title,
      description,
      category,
      date,
      time,
      location,
      city,
      organizer: currentUser.name,
      organizerRole: 'Community Lead',
      spotsTotal: Number(spotsTotal) || 40,
      imageUrl,
      sdgBadge: category === 'cleanup' ? 11 : category === 'tree_planting' ? 15 : category === 'food_drive' ? 12 : 13
    });

    setHostModalOpen(false);
    setTitle('');
    setDescription('');
    setLocation('');
  };

  const filteredEvents = events.filter(event => {
    const matchesCategory = selectedCategory === 'all' || event.category === selectedCategory;
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          event.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          event.city.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* 1. Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border border-emerald-500/30 p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-4">
            <Calendar className="w-4 h-4" /> Grassroots Volunteering Roster
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight mb-4 leading-tight">
            Community Volunteering & <br />
            <span className="text-emerald-400">Environmental Action Drives</span>
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            Join weekend beach sweeps, Miyawaki forest plantings, midnight surplus food logistics, or urban lake cleanups. Connect with grassroots changemakers and earn verified eco-volunteer hours.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-emerald-800/60">
            <div>
              <div className="text-2xl sm:text-3xl font-black text-emerald-400">34,280+</div>
              <div className="text-xs text-slate-300">Registered Volunteers</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-black text-emerald-400">180+</div>
              <div className="text-xs text-slate-300">Drives Completed</div>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <div className="text-2xl sm:text-3xl font-black text-emerald-400">+50 Pts</div>
              <div className="text-xs text-slate-300">Per RSVP Attended</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Action Toolbar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search drives by name, city..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {['all', 'cleanup', 'tree_planting', 'food_drive', 'water_action'].map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {cat.replace('_', ' ')}
            </button>
          ))}
        </div>

        {/* Host Event Button */}
        <button
          onClick={() => setHostModalOpen(true)}
          className="w-full md:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-md shadow-emerald-600/20 active:scale-95 transition-all flex-shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Host a Volunteering Event</span>
        </button>
      </div>

      {/* 3. Host Event Modal */}
      {hostModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs uppercase tracking-wider">
                <Calendar className="w-4 h-4" /> Community Drive Creator
              </div>
              <button
                onClick={() => setHostModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                Close ✕
              </button>
            </div>

            <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">
              Host a Community Volunteering Drive
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Create an open drive for your neighborhood. All volunteers will receive meeting spot coordinates and checklist guidelines.
            </p>

            <form onSubmit={handleCreateEvent} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                  Event Title
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Sanjay Van Woodland Seed Ball Dispersal Walk"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Drive Category
                  </label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as EventCategory)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="cleanup">Cleanup & Waste Segregation</option>
                    <option value="tree_planting">Native Tree Plantation</option>
                    <option value="food_drive">Surplus Food Rescue & Distribution</option>
                    <option value="water_action">Water Revival & Leak Watch</option>
                    <option value="workshop">Educational Climate Workshop</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Volunteer Capacity
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="500"
                    value={spotsTotal}
                    onChange={e => setSpotsTotal(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Date
                  </label>
                  <input
                    type="text"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    placeholder="e.g. Sunday, Dec 14"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Time Window
                  </label>
                  <input
                    type="text"
                    required
                    value={time}
                    onChange={e => setTime(e.target.value)}
                    placeholder="e.g. 07:00 AM - 10:30 AM"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    City
                  </label>
                  <select
                    value={city}
                    onChange={e => setCity(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="New Delhi">New Delhi</option>
                    <option value="Mumbai">Mumbai</option>
                    <option value="Bengaluru">Bengaluru</option>
                    <option value="Gurugram">Gurugram</option>
                    <option value="Pune">Pune</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Meeting Location Landmark
                  </label>
                  <input
                    type="text"
                    required
                    value={location}
                    onChange={e => setLocation(e.target.value)}
                    placeholder="e.g. Gate 2, Sanjay Van Entrance"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                  Description & Gear Instructions
                </label>
                <textarea
                  rows={3}
                  required
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Explain the drive objectives, what to wear (e.g., closed shoes, hat), and items provided..."
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 transition-all active:scale-95"
                >
                  Publish Volunteering Drive (+150 EcoPoints)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. Events Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredEvents.map(event => (
          <div
            key={event.id}
            className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
          >
            <div>
              <div className="relative h-48 overflow-hidden bg-slate-100 dark:bg-slate-800">
                <img
                  src={event.imageUrl}
                  alt={event.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute top-3 left-3">
                  <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-black/60 text-white backdrop-blur-md">
                    SDG {event.sdgBadge}
                  </span>
                </div>
                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-300">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{event.date} • {event.time}</span>
                  </div>
                </div>
              </div>

              <div className="p-6">
                <h4 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2 line-clamp-1">
                  {event.title}
                </h4>

                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                  {event.description}
                </p>

                <div className="space-y-1.5 text-xs text-slate-500 mb-4">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-rose-500 flex-shrink-0" />
                    <span className="truncate">{event.location}, {event.city}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                    <span>Organized by: {event.organizer} ({event.organizerRole})</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="px-6 pb-6 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-900 dark:text-white">
                  {event.spotsFilled} / {event.spotsTotal}
                </div>
                <div className="text-[10px] text-slate-400">Volunteers Joined</div>
              </div>

              <button
                onClick={() => toggleEventRSVP(event.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  event.rsvped
                    ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20 active:scale-95'
                }`}
              >
                {event.rsvped ? '✓ RSVP Confirmed' : 'Join as Volunteer'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
