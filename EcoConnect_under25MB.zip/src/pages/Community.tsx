import React, { useState } from 'react';
import { 
  Users2, 
  Award, 
  Heart, 
  Sparkles, 
  MessageSquare, 
  Send, 
  CheckCircle2, 
  Trophy, 
  Star, 
  Share2,
  Tag
} from 'lucide-react';
import { useEco } from '../context/EcoContext';

export const Community: React.FC = () => {
  const { communityStories, toggleLikeStory, addCommunityStory, currentUser } = useEco();

  const [newPostContent, setNewPostContent] = useState('');
  const [newPostTag, setNewPostTag] = useState('ZeroWaste');
  const [selectedTag, setSelectedTag] = useState<string>('all');

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim()) return;

    addCommunityStory(newPostContent, [newPostTag, 'EcoConnectCommunity']);
    setNewPostContent('');
  };

  const leaderboardUsers = [
    { rank: 1, name: 'Vikram Sengupta', role: 'Mangrove Warrior • Mumbai', points: 3420, badgesCount: 6, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80' },
    { rank: 2, name: 'Sunita Rao', role: 'Composting Lead • Delhi', points: 2980, badgesCount: 5, avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80' },
    { rank: 3, name: 'Devan Patel (You)', role: 'Community Steward', points: currentUser.ecoPoints, badgesCount: currentUser.badges.filter(b => b.unlocked).length, avatar: currentUser.avatar },
    { rank: 4, name: 'Aarav Sharma', role: 'Hazard Sentinel • Delhi', points: 1390, badgesCount: 4, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80' },
    { rank: 5, name: 'Kavita Nair', role: 'Youth Climate Corps', points: 1120, badgesCount: 3, avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80' }
  ];

  const filteredStories = communityStories.filter(story => {
    if (selectedTag === 'all') return true;
    return story.tags.some(t => t.toLowerCase() === selectedTag.toLowerCase());
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* 1. Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-indigo-950 via-slate-950 to-slate-900 border border-indigo-500/30 p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold uppercase tracking-wider mb-4">
            <Users2 className="w-4 h-4" /> Grassroots Action Network
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight mb-4 leading-tight">
            Community Hub, Leaderboards & <br />
            <span className="text-indigo-400">Eco-Champions Wall</span>
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            Share local zero-waste breakthroughs, celebrate cleanup milestones, unlock planet guardian badges, and climb the civic stewardship leaderboard.
          </p>

          <div className="flex items-center gap-4 pt-4 border-t border-indigo-800/60">
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-400" />
              <span className="text-sm font-bold text-slate-200">Your Rank: #3</span>
            </div>
            <span>•</span>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <span className="text-sm font-bold text-slate-200">{currentUser.ecoPoints} EcoPoints</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Badges Showcase */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 mb-1">
              Gamified Stewardship
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              Your Environmental Achievements & Badges
            </h3>
          </div>
          <span className="text-xs font-bold text-slate-500">
            {currentUser.badges.filter(b => b.unlocked).length} / {currentUser.badges.length} Unlocked
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          {currentUser.badges.map(badge => (
            <div
              key={badge.id}
              className={`p-5 rounded-2xl border text-center transition-all ${
                badge.unlocked
                  ? 'bg-gradient-to-b from-indigo-50/50 to-white dark:from-slate-800 dark:to-slate-900 border-indigo-500/40 shadow-sm'
                  : 'bg-slate-50/50 dark:bg-slate-900/30 border-slate-200 dark:border-slate-800 opacity-50 grayscale'
              }`}
            >
              <div className="text-4xl mb-3">{badge.icon}</div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white mb-1">
                {badge.name}
              </h4>
              <p className="text-[11px] text-slate-500 leading-snug line-clamp-2">
                {badge.description}
              </p>
              {badge.unlocked && (
                <div className="mt-3 inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                  <CheckCircle2 className="w-3 h-3" /> Unlocked
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* 3. Community Feed & Leaderboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Community Discussion Stories */}
        <div className="lg:col-span-8 space-y-6">
          {/* Post Form */}
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-3">
              Share a Field Update or Zero-Waste Win
            </h4>
            <form onSubmit={handlePostSubmit} className="space-y-3">
              <textarea
                rows={3}
                required
                value={newPostContent}
                onChange={e => setNewPostContent(e.target.value)}
                placeholder="What action did your neighborhood take today? e.g. Diverted 40kg compost, installed bird baths..."
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-indigo-500"
              />

              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Tag className="w-3.5 h-3.5 text-slate-400" />
                  <select
                    value={newPostTag}
                    onChange={e => setNewPostTag(e.target.value)}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold"
                  >
                    <option value="ZeroWaste">#ZeroWaste</option>
                    <option value="Composting">#Composting</option>
                    <option value="TreeCare">#TreeCare</option>
                    <option value="WaterSaving">#WaterSaving</option>
                    <option value="CleanShore">#CleanShore</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Post Story (+60 EcoPoints)</span>
                </button>
              </div>
            </form>
          </div>

          {/* Stories List */}
          <div className="space-y-6">
            {filteredStories.map(story => (
              <div
                key={story.id}
                className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={story.avatar}
                      alt={story.author}
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500"
                    />
                    <div>
                      <div className="text-sm font-bold text-slate-900 dark:text-white">
                        {story.author}
                      </div>
                      <div className="text-xs text-slate-400">
                        {story.role} • {story.timeAgo}
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-1.5">
                    {story.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                  {story.content}
                </p>

                {story.imageUrl && (
                  <div className="rounded-2xl overflow-hidden h-64 bg-slate-100 dark:bg-slate-800">
                    <img
                      src={story.imageUrl}
                      alt="Story update"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <button
                    onClick={() => toggleLikeStory(story.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition-all ${
                      story.liked
                        ? 'bg-rose-50 dark:bg-rose-950/70 text-rose-600 border border-rose-500/30'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 ${story.liked ? 'fill-rose-600' : ''}`} />
                    <span>{story.likes} Cheers</span>
                  </button>

                  <span className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Share2 className="w-3.5 h-3.5" /> Verified Community Action
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Leaderboard */}
        <div className="lg:col-span-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2 font-black text-slate-900 dark:text-white">
              <Trophy className="w-5 h-5 text-amber-500" />
              <span>Eco-Champions Leaderboard</span>
            </div>
          </div>

          <div className="space-y-3">
            {leaderboardUsers.map(user => (
              <div
                key={user.rank}
                className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                  user.rank === 3
                    ? 'bg-indigo-50/70 dark:bg-indigo-950/50 border-indigo-500/40 shadow-sm'
                    : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-700/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-6 h-6 rounded-full flex items-center justify-center font-black text-xs ${
                      user.rank === 1
                        ? 'bg-amber-400 text-slate-950'
                        : user.rank === 2
                        ? 'bg-slate-300 text-slate-950'
                        : user.rank === 3
                        ? 'bg-amber-600 text-white'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {user.rank}
                  </span>

                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-8 h-8 rounded-full object-cover"
                  />

                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[130px]">
                      {user.name}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate max-w-[130px]">
                      {user.role}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs font-black text-indigo-600 dark:text-indigo-400">
                    {user.points.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-slate-400">{user.badgesCount} badges</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
