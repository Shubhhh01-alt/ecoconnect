import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Sprout, 
  ArrowRight, 
  AlertTriangle, 
  Trees, 
  UtensilsCrossed, 
  Droplet, 
  Trash2, 
  Calendar, 
  ThumbsUp, 
  MapPin, 
  CheckCircle2, 
  Sparkles, 
  Users, 
  Award, 
  Heart, 
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Check
} from 'lucide-react';
import { useEco } from '../context/EcoContext';
import { FloatingLeavesCanvas } from '../components/FloatingLeavesCanvas';
import { SDGCard, sdgData } from '../components/SDGCard';

export const Home: React.FC = () => {
  const { stats, issues, events, toggleUpvoteIssue, toggleEventRSVP, awardPoints } = useEco();
  const [completedDailyTask, setCompletedDailyTask] = useState(false);

  const handleCompleteDailyChallenge = () => {
    if (completedDailyTask) return;
    setCompletedDailyTask(true);
    awardPoints(25, 'Completed Daily Eco Challenge: Carried reusable bottle');
  };

  const initiatives = [
    {
      title: 'Tree Plantation Drives',
      subtitle: 'Native Miyawaki Reforestation',
      desc: 'Pledge native saplings, locate community planting drives, and track lifetime carbon sequestration.',
      icon: Trees,
      color: 'from-emerald-500 to-green-600',
      tag: 'SDG 15: Life on Land',
      path: '/initiatives/tree-plantation',
      stats: '142k+ Trees Tracked'
    },
    {
      title: 'Surplus Food Rescue',
      subtitle: 'Zero Waste Feeding Network',
      desc: 'Directly connect banquets, restaurants, and bakeries with local shelters to redirect safe food.',
      icon: UtensilsCrossed,
      color: 'from-amber-500 to-orange-600',
      tag: 'SDG 12: Responsible Consumption',
      path: '/initiatives/food-rescue',
      stats: '86k+ Meals Rescued'
    },
    {
      title: 'Water Conservation Hub',
      subtitle: 'Freshwater Preservation',
      desc: 'Calculate household water footprints, report community pipeline leaks, and install rainwater kits.',
      icon: Droplet,
      color: 'from-sky-500 to-blue-600',
      tag: 'SDG 13: Climate Action',
      path: '/initiatives/water-conservation',
      stats: '1.2M+ Litres Conserved'
    },
    {
      title: 'Clean-up Drives & Waste',
      subtitle: 'Civic Waste Interception',
      desc: 'Join beach, lake, and park cleanups, master source segregation, and divert single-use plastics.',
      icon: Trash2,
      color: 'from-teal-500 to-emerald-700',
      tag: 'SDG 11: Sustainable Cities',
      path: '/initiatives/clean-up',
      stats: '215+ Tons Diverted'
    }
  ];

  return (
    <div className="space-y-24">
      {/* 1. Full-screen Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center pt-8 pb-16 overflow-hidden">
        {/* Animated Leaf Particles Canvas Background */}
        <FloatingLeavesCanvas />

        {/* Ambient background glowing orbs */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-emerald-500/15 via-teal-400/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 text-xs sm:text-sm font-semibold mb-8 animate-fade-in shadow-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>Empowering Citizen-Led Environmental Action • UN SDG Aligned</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-slate-900 dark:text-white tracking-tight leading-[1.1] mb-6">
            Small Actions. <br />
            <span className="bg-gradient-to-r from-emerald-600 via-teal-500 to-green-500 bg-clip-text text-transparent">
              Cleaner Communities.
            </span> <br />
            A Better Planet.
          </h1>

          {/* Subheading */}
          <p className="max-w-3xl mx-auto text-base sm:text-xl text-slate-600 dark:text-slate-300 font-normal leading-relaxed mb-10">
            EcoConnect is the community-driven environmental platform that connects citizens, NGOs, volunteers, and municipal teams to report local hazards, rescue surplus food, plant native forests, and build climate resilience together.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <Link
              to="/events"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-base shadow-xl shadow-emerald-600/30 hover:shadow-emerald-600/40 hover:-translate-y-0.5 transition-all duration-200"
            >
              <span>Join the Movement</span>
              <ArrowRight className="w-5 h-5" />
            </Link>

            <Link
              to="/report"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-2xl bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-800 hover:border-rose-500/50 hover:bg-rose-50/50 dark:hover:bg-rose-950/20 font-bold text-base shadow-sm hover:shadow-md transition-all duration-200 group"
            >
              <AlertTriangle className="w-5 h-5 text-rose-500 group-hover:scale-110 transition-transform" />
              <span>Report an Issue</span>
            </Link>
          </div>

          {/* Daily Micro-Challenge Card */}
          <div className="max-w-xl mx-auto rounded-2xl p-4 sm:p-5 bg-white/90 dark:bg-slate-900/90 border border-slate-200/80 dark:border-slate-800 shadow-xl backdrop-blur-md flex items-center justify-between gap-4 text-left">
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                  Today's Community Challenge
                </span>
                <p className="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200">
                  Carry your own reusable bottle & bag today
                </p>
              </div>
            </div>

            <button
              onClick={handleCompleteDailyChallenge}
              disabled={completedDailyTask}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 flex-shrink-0 ${
                completedDailyTask
                  ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20 active:scale-95'
              }`}
            >
              {completedDailyTask ? (
                <>
                  <Check className="w-3.5 h-3.5" /> Done (+25 pts)
                </>
              ) : (
                'I did this (+25)'
              )}
            </button>
          </div>
        </div>
      </section>

      {/* 2. Environmental Impact Statistics Ribbon */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-slate-900 text-white p-8 sm:p-12 shadow-2xl relative overflow-hidden border border-slate-800">
          <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />

          <div className="text-center max-w-2xl mx-auto mb-10">
            <h2 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-2">
              Verified Real-World Metrics
            </h2>
            <h3 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Collective Action in Real Numbers
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm mt-1">
              Every tree planted, meal delivered, and hazard reported is tracked transparently across our network.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-6 sm:gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-slate-800">
            <div className="pt-4 md:pt-0">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-emerald-400 tracking-tight">
                {stats.treesPlanted.toLocaleString()}+
              </div>
              <div className="text-xs sm:text-sm font-semibold text-slate-300 mt-1">
                Native Trees Planted
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Miyawaki Bio-reserves</div>
            </div>

            <div className="pt-4 md:pt-0 md:pl-4">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-amber-400 tracking-tight">
                {stats.mealsRescued.toLocaleString()}+
              </div>
              <div className="text-xs sm:text-sm font-semibold text-slate-300 mt-1">
                Meals Rescued
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Diverted from Landfills</div>
            </div>

            <div className="pt-4 md:pt-0 md:pl-4">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-sky-400 tracking-tight">
                {stats.wasteDivertedTons}t
              </div>
              <div className="text-xs sm:text-sm font-semibold text-slate-300 mt-1">
                Waste Diverted
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Ocean & Urban Cleanups</div>
            </div>

            <div className="pt-4 md:pt-0 md:pl-4">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-indigo-400 tracking-tight">
                {stats.volunteersActive.toLocaleString()}+
              </div>
              <div className="text-xs sm:text-sm font-semibold text-slate-300 mt-1">
                Active Volunteers
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Across 42 Urban Clusters</div>
            </div>

            <div className="pt-4 md:pt-0 md:pl-4 col-span-2 md:col-span-1">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-teal-400 tracking-tight">
                {stats.issuesResolved.toLocaleString()}+
              </div>
              <div className="text-xs sm:text-sm font-semibold text-slate-300 mt-1">
                Hazards Resolved
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Municipal & NGO Action</div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Featured Initiatives Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-eco-600 dark:text-eco-400 mb-2">
              Action Pillars
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
              Featured Community Initiatives
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 mt-1 max-w-xl">
              Choose a cause that speaks to you. Step up to plant, rescue, clean, and protect your local biome.
            </p>
          </div>
          <Link
            to="/initiatives/tree-plantation"
            className="mt-4 md:mt-0 inline-flex items-center gap-1.5 text-sm font-bold text-eco-600 dark:text-eco-400 hover:gap-2.5 transition-all"
          >
            <span>View all initiatives</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {initiatives.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="group rounded-3xl p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-eco-500/50 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-tr ${item.color} flex items-center justify-center text-white shadow-lg mb-5 group-hover:scale-105 transition-transform`}>
                    <Icon className="w-7 h-7" />
                  </div>

                  <span className="inline-block text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 mb-2">
                    {item.tag}
                  </span>

                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-eco-600 dark:group-hover:text-eco-400 transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-6">
                    {item.desc}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    {item.stats}
                  </span>
                  <Link
                    to={item.path}
                    className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 group-hover:bg-eco-600 group-hover:text-white transition-colors"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. Upcoming Community Events Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-eco-600 dark:text-eco-400 mb-2">
              Get Your Hands Dirty
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
              Upcoming Volunteer Drives
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 mt-1 max-w-xl">
              Meet like-minded neighbors, earn volunteer hours, and create measurable change in your neighborhood.
            </p>
          </div>
          <Link
            to="/events"
            className="mt-4 md:mt-0 inline-flex items-center gap-1.5 text-sm font-bold text-eco-600 dark:text-eco-400 hover:gap-2.5 transition-all"
          >
            <span>Browse all events</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.slice(0, 3).map(event => (
            <div
              key={event.id}
              className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={event.imageUrl}
                  alt={event.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute top-3 left-3">
                  <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-black/60 text-white backdrop-blur-md">
                    SDG {event.sdgBadge}
                  </span>
                </div>
                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{event.date} • {event.time}</span>
                  </div>
                </div>
              </div>

              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2 line-clamp-1">
                    {event.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 line-clamp-2 mb-4">
                    {event.description}
                  </p>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-4">
                    <MapPin className="w-4 h-4 text-rose-500 flex-shrink-0" />
                    <span className="truncate">{event.location}, {event.city}</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <div className="text-xs">
                    <span className="font-bold text-slate-800 dark:text-slate-200">
                      {event.spotsTotal - event.spotsFilled}
                    </span>{' '}
                    <span className="text-slate-500">spots left</span>
                  </div>

                  <button
                    onClick={() => toggleEventRSVP(event.id)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                      event.rsvped
                        ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30'
                        : 'bg-eco-600 hover:bg-eco-500 text-white shadow-md shadow-eco-600/20 active:scale-95'
                    }`}
                  >
                    {event.rsvped ? '✓ Attending' : 'RSVP Now'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Recent Environmental Reports Feed */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400 mb-2">
              Citizen Vigilance
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
              Recent Environmental Reports
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 mt-1 max-w-xl">
              Citizens report illegal dumping, deforestation, and water leaks. Community upvotes escalate them to civic authorities.
            </p>
          </div>
          <Link
            to="/report"
            className="mt-4 md:mt-0 inline-flex items-center gap-1.5 text-sm font-bold text-rose-600 dark:text-rose-400 hover:gap-2.5 transition-all"
          >
            <span>Submit a report</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {issues.slice(0, 4).map(issue => (
            <div
              key={issue.id}
              className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm hover:shadow-lg transition-all flex flex-col sm:flex-row gap-5"
            >
              <div className="w-full sm:w-36 h-36 rounded-2xl overflow-hidden flex-shrink-0 bg-slate-100 dark:bg-slate-800">
                <img
                  src={issue.imageUrl}
                  alt={issue.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        issue.status === 'resolved'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300'
                          : issue.status === 'in_progress'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300'
                      }`}
                    >
                      {issue.status.replace('_', ' ')}
                    </span>
                    <span className="text-[11px] text-slate-400">{issue.reportedAt}</span>
                  </div>

                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white line-clamp-1 mb-1.5">
                    {issue.title}
                  </h3>

                  <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 mb-3">
                    {issue.description}
                  </p>

                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-3">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                    <span className="truncate">{issue.location}, {issue.city}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-[11px] text-slate-400">
                    By {issue.reportedBy}
                  </span>

                  <button
                    onClick={() => toggleUpvoteIssue(issue.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      issue.hasUpvoted
                        ? 'bg-emerald-500 text-white shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                    <span>{issue.upvotes}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 6. UN Sustainable Development Goals Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="text-xs font-bold uppercase tracking-wider text-eco-600 dark:text-eco-400 mb-2">
            Global Framework • Local Execution
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
            Aligned with United Nations SDGs
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 mt-2">
            EcoConnect directly targets 4 United Nations Sustainable Development Goals through hyper-local participatory civic intervention.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {sdgData.map(sdg => (
            <SDGCard key={sdg.number} sdg={sdg} />
          ))}
        </div>
      </section>

      {/* 7. Community Testimonials / Stories Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-b from-slate-100 to-white dark:from-slate-900 dark:to-slate-950 border border-slate-200 dark:border-slate-800 p-8 sm:p-12 shadow-sm">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-eco-600 dark:text-eco-400 mb-2 block">
              Voices of the Movement
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              Community Stewards in Action
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 italic mb-6 leading-relaxed">
                "We had a chronic plastic dumping blackspot behind our school for two years. Using EcoConnect, 40 parents and students logged the issue, gathered 120 community upvotes, and organized a weekend cleanup. The municipality provided trees, and now it is a mini flower garden!"
              </p>
              <div className="flex items-center gap-3">
                <img
                  src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80"
                  alt="Ananya Roy"
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-emerald-500"
                />
                <div>
                  <div className="text-sm font-bold text-slate-900 dark:text-white">Ananya Roy</div>
                  <div className="text-xs text-slate-400">High School Teacher & Eco-Club Lead</div>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 italic mb-6 leading-relaxed">
                "Our banquet hall used to throw away pristine buffet trays after weddings because we had no reliable distribution partner late at night. With EcoConnect Food Rescue, local shelter volunteers arrive within 45 minutes. We have diverted over 2,400 meals this month alone."
              </p>
              <div className="flex items-center gap-3">
                <img
                  src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=150&q=80"
                  alt="Tariq Mansoori"
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-500"
                />
                <div>
                  <div className="text-sm font-bold text-slate-900 dark:text-white">Tariq Mansoori</div>
                  <div className="text-xs text-slate-400">Head Chef & Hospitality Director</div>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 italic mb-6 leading-relaxed">
                "The Miyawaki forest tracker gave our youth club a clear visual proof of our work. Watching our 300 planted Peepal and Neem saplings grow, while calculating the CO2 offset, keeps everyone motivated to return every weekend for weed removal and mulch maintenance."
              </p>
              <div className="flex items-center gap-3">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80"
                  alt="Kavita Nair"
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-teal-500"
                />
                <div>
                  <div className="text-sm font-bold text-slate-900 dark:text-white">Kavita Nair</div>
                  <div className="text-xs text-slate-400">Youth Climate Corps Organizer</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Call to Action Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="rounded-3xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 p-8 sm:p-14 text-white text-center shadow-2xl relative overflow-hidden">
          <div className="max-w-2xl mx-auto relative z-10">
            <h2 className="text-3xl sm:text-4xl font-black tracking-tight mb-4">
              Ready to Make Your Neighborhood Greener?
            </h2>
            <p className="text-emerald-100 text-sm sm:text-base leading-relaxed mb-8">
              Join thousands of community members transforming their local environment. Whether you have 30 minutes to report a hazard or a weekend to plant trees, your action counts.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/report"
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-white text-emerald-900 font-bold text-sm shadow-lg hover:bg-emerald-50 transition-all hover:scale-105 active:scale-95"
              >
                Report a Hazard
              </Link>
              <Link
                to="/initiatives/tree-plantation"
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-950/60 border border-white/20 text-white font-bold text-sm transition-all"
              >
                Pledge a Tree
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
