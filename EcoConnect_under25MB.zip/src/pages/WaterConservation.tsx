import React, { useState } from 'react';
import { 
  Droplet, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  Calculator, 
  CloudRain, 
  TrendingDown, 
  ShieldCheck, 
  MapPin, 
  Clock 
} from 'lucide-react';
import { useEco } from '../context/EcoContext';

export const WaterConservation: React.FC = () => {
  const { waterLeaks, reportWaterLeak, currentUser } = useEco();

  // Water footprint calculator state
  const [showerMinutes, setShowerMinutes] = useState(8);
  const [laundryLoads, setLaundryLoads] = useState(3);
  const [gardenMinutes, setGardenMinutes] = useState(15);
  const [diet, setDiet] = useState<'plant' | 'balanced' | 'meat'>('balanced');
  const [recycleRO, setRecycleRO] = useState(false);

  // Leak report state
  const [leakLocation, setLeakLocation] = useState('');
  const [leakSeverity, setLeakSeverity] = useState<'Drip' | 'Steady Stream' | 'Burst Pipe / Flooding'>('Steady Stream');
  const [leakReportSuccess, setLeakReportSuccess] = useState(false);

  // Rainwater estimator state
  const [roofArea, setRoofArea] = useState(120); // in sq meters
  const [annualRainfall, setAnnualRainfall] = useState(800); // in mm

  // Calculator logic
  const showerWater = showerMinutes * 9; // 9L/min
  const laundryWater = (laundryLoads * 60) / 7;
  const gardenWater = (gardenMinutes * 12) / 7;
  const baseDomestic = 45; // toilet, cooking, cleaning
  const dietWater = diet === 'plant' ? 30 : diet === 'balanced' ? 65 : 120;
  const roSavings = recycleRO ? 25 : 0;

  const totalDailyLiters = Math.max(20, Math.round(showerWater + laundryWater + gardenWater + baseDomestic + dietWater - roSavings));
  const totalAnnualLiters = totalDailyLiters * 365;
  const benchmarkAverage = 180; // liters/day benchmark

  // Rainwater potential calculation: Area (m2) * Rainfall (mm) * Runoff coefficient (0.85)
  const potentialHarvestLiters = Math.round(roofArea * annualRainfall * 0.85);

  const handleLeakSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const estLoss = leakSeverity === 'Drip' ? 400 : leakSeverity === 'Steady Stream' ? 4500 : 25000;
    reportWaterLeak({
      location: leakLocation,
      severity: leakSeverity,
      estimatedLossLitersPerDay: estLoss
    });
    setLeakReportSuccess(true);
    setLeakLocation('');
    setTimeout(() => setLeakReportSuccess(false), 5000);
  };

  const dailyMicroActions = [
    { title: 'Turn off tap while brushing teeth', saves: '12 Litres / day' },
    { title: 'Capture shower warm-up water for potted plants', saves: '15 Litres / day' },
    { title: 'Run washing machine with full loads only', saves: '40 Litres / cycle' },
    { title: 'Reroute RO water purifier reject tube to bucket', saves: '30 Litres / day' },
    { title: 'Install aerators on kitchen and bathroom taps', saves: '25% tap flow reduction' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* 1. Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-sky-950 via-blue-950 to-slate-900 border border-sky-500/30 p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 text-xs font-bold uppercase tracking-wider mb-4">
            <Droplet className="w-4 h-4" /> UN SDG 13: Climate Action & Water Security
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight mb-4 leading-tight">
            Water Conservation Hub & <br />
            <span className="text-sky-400">Freshwater Leak Watch</span>
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            Climate change accelerates urban water scarcity. EcoConnect empowers citizens to audit their domestic water consumption, calculate rooftop rainwater potential, and rapidly report municipal pipeline leaks to save millions of litres.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-sky-800/60">
            <div>
              <div className="text-2xl sm:text-3xl font-black text-sky-400">1.25M+</div>
              <div className="text-xs text-slate-300">Litres Conserved</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-black text-sky-400">324</div>
              <div className="text-xs text-slate-300">Public Leaks Repaired</div>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <div className="text-2xl sm:text-3xl font-black text-sky-400">1,400+</div>
              <div className="text-xs text-slate-300">Rainwater Audits Done</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Interactive Household Water Footprint Calculator */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm">
        <div className="flex items-center gap-2.5 text-xs font-bold uppercase tracking-wider text-sky-600 dark:text-sky-400 mb-2">
          <Calculator className="w-4 h-4" /> Interactive Audit Tool
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white mb-2">
          Calculate Your Daily Water Footprint
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mb-8 max-w-2xl">
          Adjust the sliders below to see your personalized daily consumption and learn where you can save the most.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Sliders Input */}
          <div className="lg:col-span-7 space-y-6">
            {/* Shower Slider */}
            <div>
              <div className="flex justify-between text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-2">
                <span>Daily Shower Time: {showerMinutes} mins</span>
                <span className="text-sky-600 dark:text-sky-400 font-extrabold">{showerWater} Litres/day</span>
              </div>
              <input
                type="range"
                min="2"
                max="25"
                value={showerMinutes}
                onChange={e => setShowerMinutes(Number(e.target.value))}
                className="w-full accent-sky-500 h-2 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Laundry Slider */}
            <div>
              <div className="flex justify-between text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-2">
                <span>Laundry Loads per Week: {laundryLoads}</span>
                <span className="text-sky-600 dark:text-sky-400 font-extrabold">{Math.round(laundryWater)} Litres/day</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={laundryLoads}
                onChange={e => setLaundryLoads(Number(e.target.value))}
                className="w-full accent-sky-500 h-2 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Garden Watering Slider */}
            <div>
              <div className="flex justify-between text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-2">
                <span>Garden Watering / Plants: {gardenMinutes} mins/week</span>
                <span className="text-sky-600 dark:text-sky-400 font-extrabold">{Math.round(gardenWater)} Litres/day</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                step="5"
                value={gardenMinutes}
                onChange={e => setGardenMinutes(Number(e.target.value))}
                className="w-full accent-sky-500 h-2 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Diet profile */}
            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-2">
                Diet Profile (Indirect Water Embedded)
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setDiet('plant')}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-all ${
                    diet === 'plant'
                      ? 'bg-sky-50 dark:bg-sky-950/70 border-sky-500 text-sky-700 dark:text-sky-300'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  🌱 Mostly Plant
                </button>
                <button
                  type="button"
                  onClick={() => setDiet('balanced')}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-all ${
                    diet === 'balanced'
                      ? 'bg-sky-50 dark:bg-sky-950/70 border-sky-500 text-sky-700 dark:text-sky-300'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  🥗 Balanced
                </button>
                <button
                  type="button"
                  onClick={() => setDiet('meat')}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-all ${
                    diet === 'meat'
                      ? 'bg-sky-50 dark:bg-sky-950/70 border-sky-500 text-sky-700 dark:text-sky-300'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  🥩 High Protein
                </button>
              </div>
            </div>

            {/* RO Filter Toggle */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <div>
                <div className="text-xs font-bold text-slate-900 dark:text-white">
                  Recycle Water Purifier (RO) Reject Water
                </div>
                <div className="text-[11px] text-slate-500">
                  Used for mopping, car wash, or garden
                </div>
              </div>
              <input
                type="checkbox"
                checked={recycleRO}
                onChange={e => setRecycleRO(e.target.checked)}
                className="w-5 h-5 accent-sky-500 rounded cursor-pointer"
              />
            </div>
          </div>

          {/* Results Summary Card */}
          <div className="lg:col-span-5 rounded-3xl bg-gradient-to-br from-sky-900 to-slate-900 text-white p-6 sm:p-8 space-y-6 shadow-xl border border-sky-700/50">
            <div className="text-xs font-bold uppercase tracking-wider text-sky-300">
              Your Daily Water Summary
            </div>

            <div className="space-y-1">
              <div className="text-5xl font-black text-sky-300 tracking-tight">
                {totalDailyLiters} <span className="text-2xl font-bold text-sky-100">L / day</span>
              </div>
              <div className="text-xs text-slate-300">
                (~{(totalAnnualLiters / 1000).toFixed(1)} thousand litres annually)
              </div>
            </div>

            <div className="pt-4 border-t border-sky-800 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">National Average Benchmark:</span>
                <span className="font-bold text-white">{benchmarkAverage} L/day</span>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Status vs Benchmark:</span>
                <span
                  className={`font-bold px-2 py-0.5 rounded-full ${
                    totalDailyLiters < benchmarkAverage
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-amber-500/20 text-amber-300'
                  }`}
                >
                  {totalDailyLiters < benchmarkAverage ? 'Eco-Efficient ✓' : 'Above Average'}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-sky-950/60 border border-sky-600/30 text-xs text-sky-200 leading-relaxed">
              💡 <strong>Action Tip:</strong> Reducing your daily shower by just 3 minutes saves{' '}
              <strong>9,850 Litres</strong> of freshwater each year!
            </div>
          </div>
        </div>
      </div>

      {/* 3. Community Water Leak Reporter & Live Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Report Leak Form */}
        <div className="lg:col-span-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400 mb-2">
            <AlertTriangle className="w-4 h-4" /> Urgent Interception
          </div>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">
            Report a Public Water Leak
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mb-6">
            Spotted broken municipal valves, burst water mains, or street tap overflows? Log it to alert municipal response squads.
          </p>

          {leakReportSuccess && (
            <div className="mb-6 p-4 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-900 dark:text-emerald-200 flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-500 flex-shrink-0" />
              <div>
                <div className="font-bold text-sm">Leak Logged (+40 EcoPoints)</div>
                <div className="text-xs">Escalated to the local water board emergency dispatch.</div>
              </div>
            </div>
          )}

          <form onSubmit={handleLeakSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1">
                Leak Location & Landmark
              </label>
              <input
                type="text"
                required
                value={leakLocation}
                onChange={e => setLeakLocation(e.target.value)}
                placeholder="e.g. Near Indiranagar Metro Pillar 42, Main Road"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1">
                Flow Severity
              </label>
              <select
                value={leakSeverity}
                onChange={e => setLeakSeverity(e.target.value as any)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-sky-500"
              >
                <option value="Drip">Drip / Slow Trickle (~350 L/day)</option>
                <option value="Steady Stream">Steady Stream (~4,500 L/day)</option>
                <option value="Burst Pipe / Flooding">Burst Pipe / Severe Street Flooding (~25,000+ L/day)</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm shadow-lg shadow-sky-600/30 transition-all active:scale-95"
            >
              Submit Leak Alert (+40 EcoPoints)
            </button>
          </form>
        </div>

        {/* Live Leak Status Feed */}
        <div className="lg:col-span-6 rounded-3xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <h4 className="text-base font-bold text-slate-900 dark:text-white">
              Recent Reported Leaks
            </h4>
            <span className="text-xs font-semibold text-sky-600 dark:text-sky-400">
              Active Vigil
            </span>
          </div>

          <div className="space-y-3">
            {waterLeaks.map(leak => (
              <div
                key={leak.id}
                className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-sm flex items-start justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        leak.status === 'Fixed'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 animate-pulse'
                      }`}
                    >
                      {leak.status}
                    </span>
                    <span className="text-[11px] text-slate-400">{leak.reportedAt}</span>
                  </div>
                  <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white mb-1">
                    {leak.location}
                  </div>
                  <div className="text-xs text-slate-500">
                    Severity: <strong>{leak.severity}</strong> (~{leak.estimatedLossLitersPerDay.toLocaleString()} L/day)
                  </div>
                </div>

                <div className="p-2 rounded-xl bg-sky-50 dark:bg-sky-950 text-sky-600 dark:text-sky-400 flex-shrink-0">
                  <Droplet className="w-4 h-4" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 4. Rainwater Harvesting Potential Estimator */}
      <div className="rounded-3xl bg-slate-900 text-white p-6 sm:p-10 shadow-xl border border-slate-800">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-sky-400 mb-2">
          <CloudRain className="w-4 h-4" /> Rainwater Harvesting Toolkit
        </div>
        <h3 className="text-2xl font-black text-white mb-2">
          Estimate Rooftop Rainwater Capture Potential
        </h3>
        <p className="text-xs sm:text-sm text-slate-400 mb-8 max-w-xl">
          Harvesting rainwater recharges falling groundwater tables and provides free water for domestic non-potable needs.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          <div>
            <label className="block text-xs font-bold uppercase text-slate-300 mb-2">
              Rooftop Area ({roofArea} m²)
            </label>
            <input
              type="range"
              min="30"
              max="500"
              step="10"
              value={roofArea}
              onChange={e => setRoofArea(Number(e.target.value))}
              className="w-full accent-sky-400 h-2 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-slate-300 mb-2">
              Annual Average Rainfall ({annualRainfall} mm)
            </label>
            <input
              type="range"
              min="300"
              max="2500"
              step="50"
              value={annualRainfall}
              onChange={e => setAnnualRainfall(Number(e.target.value))}
              className="w-full accent-sky-400 h-2 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          <div className="p-5 rounded-2xl bg-sky-950/70 border border-sky-600/40 text-center">
            <div className="text-xs font-semibold text-slate-300 mb-1">
              Annual Harvest Potential
            </div>
            <div className="text-3xl font-black text-sky-400">
              {potentialHarvestLiters.toLocaleString()} <span className="text-base font-bold">Litres</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Enough for ~{Math.round(potentialHarvestLiters / 180)} days of family domestic needs!
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
