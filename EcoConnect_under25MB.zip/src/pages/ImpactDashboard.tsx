import React, { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Trees, 
  UtensilsCrossed, 
  Droplet, 
  Trash2, 
  Download, 
  Sparkles, 
  CheckCircle2, 
  ArrowUpRight, 
  ShieldCheck 
} from 'lucide-react';
import { useEco } from '../context/EcoContext';

export const ImpactDashboard: React.FC = () => {
  const { stats, addNotification } = useEco();
  const [activeChartTab, setActiveChartTab] = useState<'co2' | 'meals' | 'water'>('co2');
  const [downloading, setDownloading] = useState(false);

  const monthlyCO2Data = [
    { month: 'Jun', value: 140 },
    { month: 'Jul', value: 210 },
    { month: 'Aug', value: 280 },
    { month: 'Sep', value: 340 },
    { month: 'Oct', value: 420 },
    { month: 'Nov', value: 580 }
  ];

  const monthlyMealsData = [
    { month: 'Jun', value: 4200 },
    { month: 'Jul', value: 6800 },
    { month: 'Aug', value: 8900 },
    { month: 'Sep', value: 12400 },
    { month: 'Oct', value: 15800 },
    { month: 'Nov', value: 19500 }
  ];

  const monthlyWaterData = [
    { month: 'Jun', value: 85000 },
    { month: 'Jul', value: 120000 },
    { month: 'Aug', value: 165000 },
    { month: 'Sep', value: 210000 },
    { month: 'Oct', value: 290000 },
    { month: 'Nov', value: 380000 }
  ];

  const cityImpacts = [
    { city: 'New Delhi & NCR', trees: '48,200', meals: '32,400', waste: '84.5t', volunteers: '12,400' },
    { city: 'Mumbai Coastal', trees: '34,500', meals: '26,800', waste: '68.2t', volunteers: '9,800' },
    { city: 'Bengaluru Lakes', trees: '29,400', meals: '15,200', waste: '38.4t', volunteers: '6,900' },
    { city: 'Pune Hills', trees: '18,600', meals: '8,400', waste: '16.2t', volunteers: '3,200' },
    { city: 'Hyderabad', trees: '12,150', meals: '3,600', waste: '8.5t', volunteers: '1,980' }
  ];

  const handleDownload = () => {
    setDownloading(true);
    setTimeout(() => {
      setDownloading(false);
      addNotification('EcoConnect Community Impact Report 2026 generated and downloaded!', 'success');
    }, 1200);
  };

  const chartData = activeChartTab === 'co2' ? monthlyCO2Data : activeChartTab === 'meals' ? monthlyMealsData : monthlyWaterData;
  const maxValue = Math.max(...chartData.map(d => d.value));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* 1. Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-teal-950 via-slate-950 to-slate-900 border border-teal-500/30 p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 text-xs font-bold uppercase tracking-wider mb-4">
            <BarChart3 className="w-4 h-4" /> Real-time Transparency Engine
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight mb-4 leading-tight">
            Environmental Impact & <br />
            <span className="text-teal-400">Carbon Sequestration Analytics</span>
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            Transparent, auditable data tracking our collective footprint reduction across native reforestation, surplus food interception, waste diversion, and municipal leak mitigation.
          </p>

          <button
            onClick={handleDownload}
            disabled={downloading}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-md transition-all active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>{downloading ? 'Compiling PDF...' : 'Download Certified Impact Report'}</span>
          </button>
        </div>
      </div>

      {/* 2. Top Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="rounded-3xl p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4">
            <Trees className="w-6 h-6" />
          </div>
          <div>
            <div className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {stats.treesPlanted.toLocaleString()}
            </div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mt-1">
              Native Trees Planted
            </div>
            <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1">
              +18% from last month
            </div>
          </div>
        </div>

        <div className="rounded-3xl p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-4">
            <UtensilsCrossed className="w-6 h-6" />
          </div>
          <div>
            <div className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {stats.mealsRescued.toLocaleString()}
            </div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mt-1">
              Meals Rescued
            </div>
            <div className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold mt-1">
              142t Methane Diverted
            </div>
          </div>
        </div>

        <div className="rounded-3xl p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="w-12 h-12 rounded-2xl bg-sky-500/10 text-sky-600 dark:text-sky-400 flex items-center justify-center mb-4">
            <Droplet className="w-6 h-6" />
          </div>
          <div>
            <div className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {(stats.waterSavedLiters / 1000000).toFixed(2)}M L
            </div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mt-1">
              Freshwater Conserved
            </div>
            <div className="text-[11px] text-sky-600 dark:text-sky-400 font-semibold mt-1">
              Via leak repairs & audits
            </div>
          </div>
        </div>

        <div className="rounded-3xl p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="w-12 h-12 rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center mb-4">
            <Trash2 className="w-6 h-6" />
          </div>
          <div>
            <div className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {stats.wasteDivertedTons} Tons
            </div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mt-1">
              Waste Diverted
            </div>
            <div className="text-[11px] text-teal-600 dark:text-teal-400 font-semibold mt-1">
              85+ Coastal & Lake Drives
            </div>
          </div>
        </div>
      </div>

      {/* 3. Interactive Visual Trends Chart */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400 mb-1">
              Monthly Growth Trends
            </div>
            <h3 className="text-2xl font-black text-slate-900 dark:text-white">
              Cumulative Action Trajectory (Past 6 Months)
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveChartTab('co2')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeChartTab === 'co2'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              CO2 Sequestered (Tons)
            </button>
            <button
              onClick={() => setActiveChartTab('meals')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeChartTab === 'meals'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              Meals Rescued
            </button>
            <button
              onClick={() => setActiveChartTab('water')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeChartTab === 'water'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              Water Saved (L)
            </button>
          </div>
        </div>

        {/* Dynamic SVG Bar Chart */}
        <div className="h-64 sm:h-72 flex items-end justify-between gap-2 sm:gap-6 pt-8 pb-4 border-b border-slate-200 dark:border-slate-800">
          {chartData.map((d, idx) => {
            const heightPercent = Math.max(15, Math.round((d.value / maxValue) * 100));
            const barBg =
              activeChartTab === 'co2'
                ? 'bg-gradient-to-t from-emerald-600 to-teal-400 hover:from-emerald-500 hover:to-teal-300'
                : activeChartTab === 'meals'
                ? 'bg-gradient-to-t from-amber-600 to-orange-400 hover:from-amber-500 hover:to-orange-300'
                : 'bg-gradient-to-t from-sky-600 to-blue-400 hover:from-sky-500 hover:to-blue-300';

            return (
              <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group">
                {/* Tooltip on hover */}
                <div className="opacity-0 group-hover:opacity-100 transition-opacity text-[11px] font-bold text-slate-800 dark:text-slate-100 mb-2">
                  {d.value.toLocaleString()}
                </div>
                {/* Bar */}
                <div
                  style={{ height: `${heightPercent}%` }}
                  className={`w-full max-w-[56px] rounded-2xl ${barBg} transition-all duration-500 shadow-md`}
                />
                <span className="text-xs font-bold text-slate-500 mt-3">{d.month}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. City Impact Leaderboard */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm">
        <h3 className="text-xl font-black text-slate-900 dark:text-white mb-6">
          Regional Chapter Impact Leaderboard
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 text-xs uppercase tracking-wider font-bold">
                <th className="pb-3">Regional Chapter</th>
                <th className="pb-3">Trees Planted</th>
                <th className="pb-3">Meals Rescued</th>
                <th className="pb-3">Waste Intercepted</th>
                <th className="pb-3">Active Volunteers</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
              {cityImpacts.map((c, idx) => (
                <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-4 font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center text-xs">
                      #{idx + 1}
                    </span>
                    {c.city}
                  </td>
                  <td className="py-4 text-emerald-600 dark:text-emerald-400 font-bold">{c.trees}</td>
                  <td className="py-4 text-amber-600 dark:text-amber-400 font-bold">{c.meals}</td>
                  <td className="py-4 text-teal-600 dark:text-teal-400 font-bold">{c.waste}</td>
                  <td className="py-4 text-indigo-600 dark:text-indigo-400 font-bold">{c.volunteers}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
