import React, { useState } from 'react';
import { 
  UtensilsCrossed, 
  Clock, 
  MapPin, 
  Plus, 
  ShieldCheck, 
  Heart, 
  CheckCircle2, 
  AlertCircle, 
  Thermometer, 
  Sparkles,
  Building,
  Truck
} from 'lucide-react';
import { useEco } from '../context/EcoContext';

export const FoodRescue: React.FC = () => {
  const { foodDonations, addFoodDonation, claimFoodDonation, currentUser } = useEco();

  // Form states
  const [formOpen, setFormOpen] = useState(false);
  const [donorName, setDonorName] = useState('');
  const [donorType, setDonorType] = useState<'Restaurant' | 'Hotel' | 'Bakery' | 'Community Kitchen' | 'Corporate' | 'Individual'>('Restaurant');
  const [title, setTitle] = useState('');
  const [quantity, setQuantity] = useState('');
  const [mealsCount, setMealsCount] = useState(50);
  const [foodType, setFoodType] = useState<'Prepared Cooked' | 'Packaged Goods' | 'Bakery & Bread' | 'Fresh Produce' | 'Dry Groceries'>('Prepared Cooked');
  const [pickupAddress, setPickupAddress] = useState('');
  const [pickupWindow, setPickupWindow] = useState('Today before 10:30 PM');
  const [tempReq, setTempReq] = useState<'Hot' | 'Chilled' | 'Room Temp'>('Hot');

  // Claim modal state
  const [claimModalId, setClaimModalId] = useState<string | null>(null);
  const [ngoName, setNgoName] = useState('Robin Hood Army Volunteer Squad');

  const handlePostDonation = (e: React.FormEvent) => {
    e.preventDefault();
    addFoodDonation({
      donorName: donorName || currentUser.name,
      donorType,
      title,
      quantity,
      mealsCount: Number(mealsCount) || 20,
      foodType,
      pickupAddress,
      pickupWindow,
      temperatureRequirement: tempReq
    });
    setFormOpen(false);
    setTitle('');
    setQuantity('');
    setPickupAddress('');
  };

  const handleConfirmClaim = () => {
    if (!claimModalId) return;
    claimFoodDonation(claimModalId, ngoName);
    setClaimModalId(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* 1. Hero Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-amber-950 via-orange-950 to-slate-900 border border-amber-500/30 p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold uppercase tracking-wider mb-4">
            <UtensilsCrossed className="w-4 h-4" /> UN SDG 12: Responsible Consumption
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight mb-4 leading-tight">
            Surplus Food Rescue & <br />
            <span className="text-amber-400">Zero Waste Feeding Network</span>
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            1/3 of all food produced globally is wasted while millions go hungry. EcoConnect bridges event caterers, restaurants, and bakeries directly with verified community shelters within a 45-minute pickup radius.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-amber-800/60">
            <div>
              <div className="text-2xl sm:text-3xl font-black text-amber-400">86,400+</div>
              <div className="text-xs text-slate-300">Meals Rescued</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-black text-amber-400">142 Tons</div>
              <div className="text-xs text-slate-300">Methane Emissions Averted</div>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <div className="text-2xl sm:text-3xl font-black text-amber-400">120+</div>
              <div className="text-xs text-slate-300">Shelter & NGO Partners</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Action Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <h3 className="text-lg font-black text-slate-900 dark:text-white">
            Live Surplus Food Board
          </h3>
          <p className="text-xs text-slate-500">
            Freshly prepared meals and bulk food batches available for immediate dispatch.
          </p>
        </div>

        <button
          onClick={() => setFormOpen(true)}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm shadow-md shadow-amber-600/20 active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Post Surplus Food Donation</span>
        </button>
      </div>

      {/* 3. Post Donation Modal */}
      {formOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-amber-600 font-bold text-xs uppercase tracking-wider">
                <UtensilsCrossed className="w-4 h-4" /> Surplus Rescue Intake
              </div>
              <button
                onClick={() => setFormOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                Close ✕
              </button>
            </div>

            <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">
              Post Surplus Food Donation
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Provide accurate details so local shelters and volunteer dispatchers can arrive prepared.
            </p>

            <form onSubmit={handlePostDonation} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Donor / Venue Name
                  </label>
                  <input
                    type="text"
                    required
                    value={donorName}
                    onChange={e => setDonorName(e.target.value)}
                    placeholder="e.g. Radisson Banquet Hall"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Donor Type
                  </label>
                  <select
                    value={donorType}
                    onChange={e => setDonorType(e.target.value as any)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="Restaurant">Restaurant</option>
                    <option value="Hotel">Hotel / Banquet</option>
                    <option value="Bakery">Bakery</option>
                    <option value="Community Kitchen">Community Kitchen</option>
                    <option value="Corporate">Corporate Cafeteria</option>
                    <option value="Individual">Individual Citizen</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                  Food Description & Items
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Rice, Dal Makhani, Mixed Vegetable Curry, 150 Rotis"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Food Category
                  </label>
                  <select
                    value={foodType}
                    onChange={e => setFoodType(e.target.value as any)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="Prepared Cooked">Prepared Cooked</option>
                    <option value="Bakery & Bread">Bakery & Bread</option>
                    <option value="Fresh Produce">Fresh Produce</option>
                    <option value="Packaged Goods">Packaged Goods</option>
                    <option value="Dry Groceries">Dry Groceries</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Estimated Meals
                  </label>
                  <input
                    type="number"
                    min="5"
                    value={mealsCount}
                    onChange={e => setMealsCount(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Temp Requirement
                  </label>
                  <select
                    value={tempReq}
                    onChange={e => setTempReq(e.target.value as any)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="Hot">Hot (&gt;60°C)</option>
                    <option value="Chilled">Chilled (&lt;5°C)</option>
                    <option value="Room Temp">Room Temp</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                  Quantity Description
                </label>
                <input
                  type="text"
                  required
                  value={quantity}
                  onChange={e => setQuantity(e.target.value)}
                  placeholder="e.g. 80 Portions / 25 kg in 4 sealed trays"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Pickup Window
                  </label>
                  <input
                    type="text"
                    required
                    value={pickupWindow}
                    onChange={e => setPickupWindow(e.target.value)}
                    placeholder="e.g. Tonight before 11:00 PM"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                    Pickup Address
                  </label>
                  <input
                    type="text"
                    required
                    value={pickupAddress}
                    onChange={e => setPickupAddress(e.target.value)}
                    placeholder="e.g. Service Lane 4, Gate B"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm shadow-lg shadow-amber-600/30 transition-all active:scale-95"
                >
                  Publish Food Rescue Alert (+80 EcoPoints)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. Claim Modal */}
      {claimModalId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
              Dispatch Volunteer Squad
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Enter your shelter or volunteer organization name to lock this donation and receive the donor's contact gate pass.
            </p>

            <div className="mb-4">
              <label className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1">
                Organization / Shelter Name
              </label>
              <input
                type="text"
                value={ngoName}
                onChange={e => setNgoName(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                onClick={() => setClaimModalId(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-800"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmClaim}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md"
              >
                Confirm Claim & Dispatch
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. Food Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {foodDonations.map(food => (
          <div
            key={food.id}
            className={`rounded-3xl border p-6 flex flex-col justify-between transition-all ${
              food.status === 'claimed'
                ? 'bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-80'
                : 'bg-white dark:bg-slate-900 border-amber-500/40 shadow-sm hover:shadow-xl'
            }`}
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
                  {food.donorType}
                </span>
                <span
                  className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                    food.status === 'claimed'
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                      : 'bg-amber-500 text-white animate-pulse'
                  }`}
                >
                  {food.status === 'claimed' ? '✓ Claimed' : 'Available Now'}
                </span>
              </div>

              <h4 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2 line-clamp-1">
                {food.title}
              </h4>

              <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400 mb-6">
                <div className="flex items-center gap-2">
                  <UtensilsCrossed className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />
                  <span className="font-semibold text-slate-900 dark:text-slate-200">
                    {food.quantity} (~{food.mealsCount} Meals)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                  <span>Pickup: {food.pickupWindow}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Thermometer className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                  <span>Temp: {food.temperatureRequirement}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                  <span className="truncate">{food.pickupAddress}</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
              {food.status === 'claimed' ? (
                <div className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Claimed by {food.claimedBy}</span>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">By {food.donorName}</span>
                  <button
                    onClick={() => setClaimModalId(food.id)}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20 active:scale-95"
                  >
                    Claim for Shelter
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* 6. Food Safety Standards Guidelines */}
      <div className="rounded-3xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 p-6 sm:p-8">
        <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-500" />
          EcoConnect Strict Food Safety Protocols
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs sm:text-sm text-slate-600 dark:text-slate-400">
          <div>
            <div className="font-bold text-slate-800 dark:text-slate-200 mb-1">
              1. 2-Hour Window Rule
            </div>
            Cooked food must be transferred to insulated thermal transport bags within 2 hours of meal conclusion to prevent bacterial growth.
          </div>
          <div>
            <div className="font-bold text-slate-800 dark:text-slate-200 mb-1">
              2. Clean Packaging Standards
            </div>
            Food must never be touched by bare hands and must be packed in food-grade foil trays or clean stainless steel canisters provided by our network.
          </div>
          <div>
            <div className="font-bold text-slate-800 dark:text-slate-200 mb-1">
              3. Recipient Verification
            </div>
            Deliveries are made exclusively to registered children's homes, elder shelters, and vetted community feeding centers with immediate dining facilities.
          </div>
        </div>
      </div>
    </div>
  );
};
