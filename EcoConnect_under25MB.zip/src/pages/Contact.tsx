import React, { useState } from 'react';
import { 
  PhoneCall, 
  Mail, 
  MapPin, 
  Send, 
  CheckCircle2, 
  HelpCircle, 
  ChevronDown, 
  Building, 
  Sparkles 
} from 'lucide-react';
import { useEco } from '../context/EcoContext';

export const Contact: React.FC = () => {
  const { addNotification } = useEco();

  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [inquiryType, setInquiryType] = useState('Volunteer Registration');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  // FAQ accordion state
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    addNotification(`Inquiry received from ${name}! Our team will respond within 24 hours.`, 'success');
    setName('');
    setEmail('');
    setMessage('');
    setTimeout(() => setSent(false), 5000);
  };

  const faqs = [
    {
      q: 'How are tree plantation sites verified and monitored?',
      a: 'Every tree planted through EcoConnect is assigned GPS coordinates and documented with initial sapling photos. Partner conservation trusts provide quarterly monitoring updates, drip irrigation maintenance, and replacement saplings for the first 3 years to ensure an 85%+ survival rate.'
    },
    {
      q: 'How does the surplus food rescue platform ensure hygiene?',
      a: 'Donors must adhere to our 2-hour window rule: food must be transferred to clean food-grade containers within 2 hours of meal service. Food is transported in thermal insulated carriers directly to registered shelters and served within 90 minutes of arrival.'
    },
    {
      q: 'Can any citizen report an environmental hazard?',
      a: 'Yes! Anyone can log illegal waste dumps, deforestation, water contamination, or burst municipal pipes. Verified photo evidence and geolocation are required. Community upvotes push urgent incidents to local municipal ward officials and environmental squads.'
    },
    {
      q: 'How do EcoPoints work?',
      a: 'EcoPoints are earned by taking verified real-world actions: reporting a hazard (+100 pts), pledging a tree (+120 pts), posting food donations (+80 pts), or RSVPing and attending clean-up drives (+50 pts). Points unlock badges, community recognition, and partner rewards.'
    },
    {
      q: 'Can corporate organizations partner for CSR drives?',
      a: 'Absolutely. We coordinate customized corporate employee volunteer drives, Miyawaki micro-forest sponsorships, and zero-waste office audits with audited impact certification aligned with UN SDGs.'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* 1. Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border border-emerald-500/30 p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-4">
            <PhoneCall className="w-4 h-4" /> Connect with EcoConnect
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight mb-4 leading-tight">
            Get Involved, Partner & <br />
            <span className="text-emerald-400">Join the Collective</span>
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Have questions about hosting an event, onboarding your NGO shelter, sponsoring a tree plantation drive, or integrating municipal response teams? Our team is here to support you.
          </p>
        </div>
      </div>

      {/* 2. Contact Form & Hub Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Contact Form */}
        <div className="lg:col-span-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm">
          <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">
            Send Us a Message
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mb-6">
            Fill in your details and we'll connect you with your regional coordinator.
          </p>

          {sent && (
            <div className="mb-6 p-4 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-900 dark:text-emerald-200 flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-500 flex-shrink-0" />
              <div>
                <div className="font-bold text-sm">Message Sent Successfully!</div>
                <div className="text-xs">Thank you for reaching out. A team member will respond shortly.</div>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1">
                  Your Full Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Maya Iyer"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="maya@example.org"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1">
                Inquiry Nature
              </label>
              <select
                value={inquiryType}
                onChange={e => setInquiryType(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
              >
                <option value="Volunteer Registration">Individual Volunteer Registration</option>
                <option value="NGO Partner Onboarding">NGO / Food Shelter Partnership</option>
                <option value="Corporate CSR">Corporate CSR & Sponsorship</option>
                <option value="Municipal Integration">Municipal Ward Authority Integration</option>
                <option value="Press / Media">Press & Media Inquiry</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1">
                Message & Collaboration Details
              </label>
              <textarea
                rows={4}
                required
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Tell us about your organization, community initiative, or how you would like to collaborate..."
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Send Message</span>
            </button>
          </form>
        </div>

        {/* Hub Locations & Direct Contact */}
        <div className="lg:col-span-5 space-y-6">
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
            <h3 className="text-xl font-black text-slate-900 dark:text-white">
              Direct Contact & Coordination Hubs
            </h3>

            <div className="space-y-4 text-xs sm:text-sm">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-slate-900 dark:text-white">General & Press Email</div>
                  <div className="text-slate-500">contact@ecoconnect.org</div>
                  <div className="text-slate-500">partnerships@ecoconnect.org</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5">
                  <PhoneCall className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-slate-900 dark:text-white">Emergency Environmental Helpline</div>
                  <div className="text-slate-500">+91 1800-ECO-HELP (Toll-Free, 24/7)</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-slate-900 dark:text-white">Central Operations Hub</div>
                  <div className="text-slate-500">EcoConnect Climate Innovation Hub, Level 4</div>
                  <div className="text-slate-500">Lodhi Institutional Area, New Delhi 110003</div>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-3xl bg-slate-900 text-white p-6 sm:p-8 shadow-md border border-slate-800">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400 mb-2">
              <Sparkles className="w-4 h-4" /> Verified NGO Status
            </div>
            <h4 className="font-bold text-base text-white mb-2">
              Are you an environmental NGO or Food Bank?
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Get direct dispatch dashboard access, verified volunteer squads, and free surplus food alerts mapped to your delivery vehicle routes.
            </p>
            <span className="text-xs font-bold text-emerald-400">
              Response time: Under 12 hours for verified shelters
            </span>
          </div>
        </div>
      </div>

      {/* 3. Interactive FAQ Accordion */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm">
        <div className="text-center max-w-xl mx-auto mb-8">
          <div className="flex items-center justify-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
            <HelpCircle className="w-4 h-4" /> Clarifications
          </div>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white">
            Frequently Asked Questions
          </h3>
        </div>

        <div className="space-y-3 max-w-3xl mx-auto">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden transition-all"
              >
                <button
                  type="button"
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-4 sm:p-5 text-left font-bold text-sm sm:text-base text-slate-900 dark:text-white flex items-center justify-between gap-4 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-slate-400 transition-transform duration-200 flex-shrink-0 ${
                      isOpen ? 'rotate-180 text-emerald-500' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800/60 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
