import React from 'react';
import { 
  Building2, 
  RefreshCw, 
  Flame, 
  Trees, 
  ShieldCheck, 
  Globe, 
  Users, 
  Heart, 
  Target, 
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { sdgData } from '../components/SDGCard';

export const About: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* 1. Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border border-emerald-500/30 p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-4">
            <Globe className="w-4 h-4" /> Global Goals • Hyper-Local Action
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight mb-4 leading-tight">
            About EcoConnect & Our <br />
            <span className="text-emerald-400">UN SDG Commitment</span>
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            EcoConnect was founded on a simple realization: while climate change and environmental destruction feel overwhelmingly vast, ecological action happens on street corners, neighborhood wetlands, and banquet halls.
          </p>

          <div className="flex flex-wrap gap-3 pt-2">
            <span className="px-3 py-1 rounded-xl bg-white/10 text-xs font-bold">100% Free & Open Platform</span>
            <span className="px-3 py-1 rounded-xl bg-white/10 text-xs font-bold">Verified Civic Impact</span>
            <span className="px-3 py-1 rounded-xl bg-white/10 text-xs font-bold">Participatory Governance</span>
          </div>
        </div>
      </div>

      {/* 2. Mission & Vision */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 shadow-sm">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4">
            <Target className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-black text-slate-900 dark:text-white mb-3">
            Our Purpose & Vision
          </h3>
          <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed mb-4">
            To transform passive environmental concern into structured, verifiable community-led action. We envision resilient, green cities where every citizen has an intuitive digital tool to protect local biodiversity and hold civic systems accountable.
          </p>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Decentralized environmental problem detection</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Zero-waste food & materials redistribution</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Restoration of degraded urban tree canopies</span>
            </li>
          </ul>
        </div>

        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 shadow-sm">
          <div className="w-12 h-12 rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center mb-4">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-black text-slate-900 dark:text-white mb-3">
            How We Ensure Accountability
          </h3>
          <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed mb-4">
            Environmental claims often suffer from greenwashing. EcoConnect implements cryptographic timestamps, GPS geolocation validation, before-and-after photo reviews, and multi-volunteer verification to ensure every metric is real.
          </p>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-500" />
              <span>Civic escalation tickets sent directly to municipal boards</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-500" />
              <span>Mandatory 3-year survival tracking for all tree saplings</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-500" />
              <span>Shelter-verified receipt confirmation for rescued meals</span>
            </li>
          </ul>
        </div>
      </div>

      {/* 3. Deep Dive into UN SDGs */}
      <div className="space-y-8">
        <div className="text-center max-w-2xl mx-auto">
          <div className="text-xs font-bold uppercase tracking-wider text-eco-600 dark:text-eco-400 mb-2">
            The 2030 Agenda
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-slate-900 dark:text-white">
            United Nations Sustainable Development Goals
          </h2>
          <p className="text-sm text-slate-500 mt-2">
            Detailed breakdown of the 4 international goals integrated into EcoConnect.
          </p>
        </div>

        <div className="space-y-6">
          {sdgData.map(sdg => {
            const Icon = sdg.icon;
            return (
              <div
                key={sdg.number}
                className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm flex flex-col lg:flex-row gap-6 items-start justify-between"
              >
                <div className="flex items-start gap-4 flex-1">
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center font-black text-white text-xl shadow-md flex-shrink-0"
                    style={{ backgroundColor: sdg.color }}
                  >
                    {sdg.number}
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                      SDG {sdg.number}: {sdg.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                      {sdg.subtitle}
                    </p>
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200">
                      <strong>Target:</strong> {sdg.targetFocus}
                    </div>
                  </div>
                </div>

                <div className="lg:w-80 pt-4 lg:pt-0 lg:border-l lg:border-slate-100 lg:dark:border-slate-800 lg:pl-6 flex flex-col justify-between h-full space-y-4">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                      EcoConnect Tangible Impact
                    </span>
                    <p className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                      {sdg.ourImpact}
                    </p>
                  </div>
                  <Link
                    to={sdg.linkRoute}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-eco-600 dark:text-eco-400 hover:gap-2 transition-all"
                  >
                    <span>Launch initiative</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Leadership & Partners */}
      <div className="rounded-3xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 p-8 sm:p-12 text-center">
        <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">
          Co-designed with 50+ Ecological Organizations
        </h3>
        <p className="text-xs sm:text-sm text-slate-500 max-w-xl mx-auto mb-8">
          EcoConnect works in active partnership with municipal corporations, youth environmental networks, and certified zero-waste trusts.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-6 text-xs font-bold uppercase tracking-wider text-slate-400">
          <span className="px-4 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            Delhi Pollution Control Liaison
          </span>
          <span className="px-4 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            Robin Hood Feast Project
          </span>
          <span className="px-4 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            Ocean Warriors India
          </span>
          <span className="px-4 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            Afforest Miyawaki Trust
          </span>
        </div>
      </div>
    </div>
  );
};
