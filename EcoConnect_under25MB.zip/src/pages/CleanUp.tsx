import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Trash2, 
  Search, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  Calendar,
  Layers,
  Recycle
} from 'lucide-react';
import { useEco } from '../context/EcoContext';

interface WasteItem {
  name: string;
  category: 'Dry / Recyclable' | 'Wet / Organic Compost' | 'Domestic Hazardous' | 'E-Waste / Specialized';
  binColor: string;
  binBg: string;
  disposalTip: string;
}

const wasteDirectory: WasteItem[] = [
  { name: 'Banana Peels & Vegetable Scraps', category: 'Wet / Organic Compost', binColor: 'text-emerald-500', binBg: 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500/30', disposalTip: 'Add directly to home composting unit or green municipal bin.' },
  { name: 'Cardboard Delivery Boxes', category: 'Dry / Recyclable', binColor: 'text-blue-500', binBg: 'bg-blue-50 dark:bg-blue-950/60 border-blue-500/30', disposalTip: 'Flatten boxes, remove plastic tape, and keep dry in blue recycling bin.' },
  { name: 'Plastic Water Bottles (PET 1)', category: 'Dry / Recyclable', binColor: 'text-blue-500', binBg: 'bg-blue-50 dark:bg-blue-950/60 border-blue-500/30', disposalTip: 'Rinse cleanly, crush to reduce volume, keep cap on.' },
  { name: 'Used Cooking Oil', category: 'Domestic Hazardous', binColor: 'text-rose-500', binBg: 'bg-rose-50 dark:bg-rose-950/60 border-rose-500/30', disposalTip: 'Never pour down kitchen sinks! Cool in a sealed glass jar and drop at biodiesel depot.' },
  { name: 'Expired Medicines & Blister Packs', category: 'Domestic Hazardous', binColor: 'text-rose-500', binBg: 'bg-rose-50 dark:bg-rose-950/60 border-rose-500/30', disposalTip: 'Take to pharmacy take-back bins or hazardous red bin. Do not flush.' },
  { name: 'Old Smartphones & Chargers', category: 'E-Waste / Specialized', binColor: 'text-purple-500', binBg: 'bg-purple-50 dark:bg-purple-950/60 border-purple-500/30', disposalTip: 'Deposit at certified e-waste collection center for rare earth metal recovery.' },
  { name: 'Broken Glass Jars', category: 'Dry / Recyclable', binColor: 'text-blue-500', binBg: 'bg-blue-50 dark:bg-blue-950/60 border-blue-500/30', disposalTip: 'Wrap in thick newspaper before placing in dry bin to protect sanitary workers.' },
  { name: 'Coffee Grounds & Tea Leaves', category: 'Wet / Organic Compost', binColor: 'text-emerald-500', binBg: 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500/30', disposalTip: 'Excellent nitrogen source for garden soil and compost piles.' },
  { name: 'Alkaline AA/AAA Batteries', category: 'Domestic Hazardous', binColor: 'text-rose-500', binBg: 'bg-rose-50 dark:bg-rose-950/60 border-rose-500/30', disposalTip: 'Contains heavy metals. Tape terminals and drop in neighborhood battery bin.' },
  { name: 'Pizza Boxes with Heavy Grease', category: 'Wet / Organic Compost', binColor: 'text-emerald-500', binBg: 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500/30', disposalTip: 'Grease contaminates paper recycling. Tear greasy bottom for compost, recycle clean top.' }
];

export const CleanUp: React.FC = () => {
  const { events } = useEco();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredWaste = wasteDirectory.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* 1. Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-teal-950 via-emerald-950 to-slate-900 border border-teal-500/30 p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 text-xs font-bold uppercase tracking-wider mb-4">
            <Trash2 className="w-4 h-4" /> UN SDG 11: Sustainable Cities & Communities
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight mb-4 leading-tight">
            Clean-up Drives & <br />
            <span className="text-teal-400">Zero-Waste Segregation Hub</span>
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            From fragile coastal shorelines to neighborhood dump blackspots, EcoConnect mobilizes community clean-up squads and educates citizens on source-level waste segregation to build truly circular cities.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-teal-800/60">
            <div>
              <div className="text-2xl sm:text-3xl font-black text-teal-400">215+ Tons</div>
              <div className="text-xs text-slate-300">Waste Intercepted</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-black text-teal-400">85+</div>
              <div className="text-xs text-slate-300">Water Bodies Cleaned</div>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <div className="text-2xl sm:text-3xl font-black text-teal-400">4,200+</div>
              <div className="text-xs text-slate-300">Clean-up Champions</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. "Can I Recycle This?" Waste Segregation Finder */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400 mb-2">
              <Recycle className="w-4 h-4" /> Waste Segregation Cheat-Sheet
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              Can I Recycle This? Item Search
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Source segregation is the #1 way to keep waste out of oceans and landfills.
            </p>
          </div>

          <div className="mt-4 md:mt-0 relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search item (e.g. battery, glass, oil)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-teal-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredWaste.map((item, idx) => (
            <div
              key={idx}
              className={`p-4 rounded-2xl border transition-all ${item.binBg}`}
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <h4 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                  {item.name}
                </h4>
                <span className={`text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full ${item.binColor} bg-white dark:bg-slate-900 shadow-sm`}>
                  {item.category}
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                {item.disposalTip}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Before & After Transformation Gallery */}
      <div>
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="text-xs font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400 mb-2">
            Visible Community Impact
          </div>
          <h3 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            Transformation Showcases
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            See how grassroots volunteer power restored degraded ecosystems.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Card 1 */}
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="grid grid-cols-2 h-56">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?auto=format&fit=crop&w=600&q=80"
                  alt="Before cleanup"
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-3 left-3 text-[10px] font-bold px-2.5 py-1 rounded-full bg-rose-600 text-white shadow-md">
                  BEFORE: 4.8t Plastic Dump
                </span>
              </div>
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=600&q=80"
                  alt="After cleanup"
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-3 right-3 text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-600 text-white shadow-md">
                  AFTER: Restored Shoreline
                </span>
              </div>
            </div>
            <div className="p-6">
              <h4 className="font-bold text-base text-slate-900 dark:text-white mb-1">
                Juhu Coastal Mangrove & Estuary Restoration
              </h4>
              <p className="text-xs text-slate-500">
                120 youth volunteers pulled out discarded nylon fishing nets, plastic bottles, and thermocol trays across 2 weekends.
              </p>
            </div>
          </div>

          {/* Card 2 */}
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="grid grid-cols-2 h-56">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=600&q=80"
                  alt="Before park cleanup"
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-3 left-3 text-[10px] font-bold px-2.5 py-1 rounded-full bg-rose-600 text-white shadow-md">
                  BEFORE: Chronic Blackspot
                </span>
              </div>
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1588880331179-bc9b93a8cb5e?auto=format&fit=crop&w=600&q=80"
                  alt="After park transformation"
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-3 right-3 text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-600 text-white shadow-md">
                  AFTER: Urban Pollinator Park
                </span>
              </div>
            </div>
            <div className="p-6">
              <h4 className="font-bold text-base text-slate-900 dark:text-white mb-1">
                Sector 18 Neighborhood Waste-to-Park Transformation
              </h4>
              <p className="text-xs text-slate-500">
                Residents converted an illegal construction dump into a native floral garden with drip irrigation and solar lights.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Action CTA */}
      <div className="p-8 rounded-3xl bg-teal-50 dark:bg-teal-950/40 border border-teal-500/30 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-xl font-black text-slate-900 dark:text-white mb-1">
            Want to join an upcoming neighborhood cleanup drive?
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
            We provide biodegradable gloves, safety masks, segregation gunny sacks, and drinking water.
          </p>
        </div>
        <Link
          to="/events"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-sm shadow-md flex-shrink-0"
        >
          <span>Find Cleanup Events</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};
