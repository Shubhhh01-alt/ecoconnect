import React, { useState } from 'react';
import { 
  AlertTriangle, 
  MapPin, 
  Camera, 
  ThumbsUp, 
  CheckCircle2, 
  Filter, 
  Clock, 
  Sparkles, 
  Upload, 
  ShieldAlert,
  Search,
  Check
} from 'lucide-react';
import { useEco } from '../context/EcoContext';
import { IssueCategory, IssueSeverity, IssueStatus } from '../types';

export const ReportIssue: React.FC = () => {
  const { issues, addIssue, toggleUpvoteIssue, currentUser } = useEco();

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<IssueCategory>('dumping');
  const [severity, setSeverity] = useState<IssueSeverity>('medium');
  const [location, setLocation] = useState('');
  const [city, setCity] = useState('New Delhi');
  const [imageUrl, setImageUrl] = useState('https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?auto=format&fit=crop&w=800&q=80');
  const [submitted, setSubmitted] = useState(false);

  // Filters
  const [selectedFilterCategory, setSelectedFilterCategory] = useState<string>('all');
  const [selectedFilterStatus, setSelectedFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const samplePhotos = [
    { label: 'Plastic Dump', url: 'https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?auto=format&fit=crop&w=800&q=80' },
    { label: 'Water Leak', url: 'https://images.unsplash.com/photo-1584467735871-8e85353a8413?auto=format&fit=crop&w=800&q=80' },
    { label: 'Deforestation', url: 'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?auto=format&fit=crop&w=800&q=80' },
    { label: 'Sewage Overflow', url: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80' }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description || !location) return;

    addIssue({
      title,
      description,
      category,
      severity,
      status: 'reported',
      location,
      city,
      reportedBy: currentUser.name,
      imageUrl
    });

    setSubmitted(true);
    setTitle('');
    setDescription('');
    setLocation('');
    setTimeout(() => setSubmitted(false), 6000);
  };

  const filteredIssues = issues.filter(issue => {
    const matchesCategory = selectedFilterCategory === 'all' || issue.category === selectedFilterCategory;
    const matchesStatus = selectedFilterStatus === 'all' || issue.status === selectedFilterStatus;
    const matchesSearch = issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          issue.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          issue.city.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesStatus && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* 1. Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-rose-950 via-slate-950 to-slate-900 border border-rose-500/30 p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-bold uppercase tracking-wider mb-4">
            <ShieldAlert className="w-4 h-4" /> Citizen Environmental Vigilance
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight mb-4 leading-tight">
            Report an Environmental Problem <br />
            <span className="text-rose-400">in Your Community</span>
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            Illegal waste dumping, municipal water pipe bursts, unauthorized tree felling, or industrial sewage runoff? Report it with photographic proof. Community upvotes escalate incidents directly to civic ward counselors and volunteer squads.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-rose-800/60">
            <div>
              <div className="text-2xl sm:text-3xl font-black text-rose-400">1,842+</div>
              <div className="text-xs text-slate-300">Hazards Resolved</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-black text-rose-400">&lt;48 Hours</div>
              <div className="text-xs text-slate-300">Avg. Civic Review Time</div>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <div className="text-2xl sm:text-3xl font-black text-rose-400">+100 Pts</div>
              <div className="text-xs text-slate-300">Earned per Verified Report</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Interactive Incident Reporting Form */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm">
        <div className="flex items-center gap-2.5 text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400 mb-2">
          <AlertTriangle className="w-4 h-4" /> Incident Intake Console
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white mb-2">
          Submit New Environmental Incident
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mb-8 max-w-2xl">
          Provide accurate details and photographic proof. Your report will be immediately geocoded and published for community upvoting and escalation.
        </p>

        {submitted && (
          <div className="mb-8 p-5 rounded-2xl bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-500/40 text-emerald-900 dark:text-emerald-200 flex items-center gap-4 animate-in fade-in">
            <CheckCircle2 className="w-7 h-7 text-emerald-500 flex-shrink-0" />
            <div>
              <div className="font-bold text-base">Report Submitted Successfully! (+100 EcoPoints)</div>
              <div className="text-xs text-emerald-700 dark:text-emerald-300">
                Token #EC-{Date.now().toString().slice(-6)} created. Community members can now upvote your report to accelerate municipal action.
              </div>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1.5">
                Issue Title / Headline
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Hazardous chemical dumping near school drainage canal"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1.5">
                Hazard Category
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as IssueCategory)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-rose-500"
              >
                <option value="dumping">Illegal Plastic & Commercial Waste Dumping</option>
                <option value="water">Water Contamination / Major Pipeline Leak</option>
                <option value="deforestation">Unauthorized Tree Felling / Deforestation</option>
                <option value="air">Open Biomass / Industrial Smoke Pollution</option>
                <option value="sewage">Open Sewage Overflow / Drain Blockage</option>
                <option value="wildlife">Injured Wildlife / Habitat Encroachment</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1.5">
              Incident Description & Observable Hazard
            </label>
            <textarea
              rows={3}
              required
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Describe the approximate quantity, odor, duration, risks to pedestrians, or involved vehicles/parties..."
              className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-rose-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1.5">
                Severity Level
              </label>
              <select
                value={severity}
                onChange={e => setSeverity(e.target.value as IssueSeverity)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-rose-500"
              >
                <option value="low">Low (Cosmetic, Minor litter)</option>
                <option value="medium">Medium (Sidewalk blockage, smelly drain)</option>
                <option value="high">High (Severe pipe burst, burning plastics)</option>
                <option value="critical">Critical (Toxic waste, heritage trees felling)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1.5">
                City / Region
              </label>
              <select
                value={city}
                onChange={e => setCity(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-rose-500"
              >
                <option value="New Delhi">New Delhi (NCR)</option>
                <option value="Mumbai">Mumbai</option>
                <option value="Bengaluru">Bengaluru</option>
                <option value="Pune">Pune</option>
                <option value="Gurugram">Gurugram</option>
                <option value="Hyderabad">Hyderabad</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1.5">
                Street / Landmark Address
              </label>
              <input
                type="text"
                required
                value={location}
                onChange={e => setLocation(e.target.value)}
                placeholder="e.g. Indiranagar 14th Cross, Near Park Gate"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-rose-500"
              />
            </div>
          </div>

          {/* Photo attachment simulator */}
          <div>
            <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-2">
              Attach Photographic Evidence (Select or Paste Image URL)
            </label>
            <div className="flex flex-wrap items-center gap-3 mb-3">
              {samplePhotos.map((item, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setImageUrl(item.url)}
                  className={`text-xs font-semibold px-3 py-1.5 rounded-xl border transition-all flex items-center gap-1.5 ${
                    imageUrl === item.url
                      ? 'bg-rose-50 dark:bg-rose-950/70 border-rose-500 text-rose-700 dark:text-rose-300'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>

            <div className="flex gap-4 items-center">
              <input
                type="url"
                value={imageUrl}
                onChange={e => setImageUrl(e.target.value)}
                placeholder="Image URL..."
                className="flex-1 px-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-rose-500"
              />
              <div className="w-16 h-12 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 flex-shrink-0 bg-slate-100">
                <img src={imageUrl} alt="Preview" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-4 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold text-sm sm:text-base shadow-xl shadow-rose-600/30 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <AlertTriangle className="w-5 h-5" />
              <span>Publish Environmental Incident Alert (+100 EcoPoints)</span>
            </button>
          </div>
        </form>
      </div>

      {/* 3. Community Incident Reports Feed & Filter Toolbar */}
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
              Live Verified Roster
            </div>
            <h3 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              Community Incident Feed ({filteredIssues.length})
            </h3>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search reports..."
                className="pl-8 pr-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-rose-500"
              />
            </div>

            <select
              value={selectedFilterCategory}
              onChange={e => setSelectedFilterCategory(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold focus:ring-2 focus:ring-rose-500"
            >
              <option value="all">All Categories</option>
              <option value="dumping">Waste Dumping</option>
              <option value="water">Water Hazard</option>
              <option value="deforestation">Deforestation</option>
              <option value="air">Air Smoke</option>
            </select>

            <select
              value={selectedFilterStatus}
              onChange={e => setSelectedFilterStatus(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold focus:ring-2 focus:ring-rose-500"
            >
              <option value="all">All Statuses</option>
              <option value="reported">Reported</option>
              <option value="in_review">In Review</option>
              <option value="in_progress">In Progress</option>
              <option value="resolved">Resolved</option>
            </select>
          </div>
        </div>

        {/* Issue Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredIssues.map(issue => (
            <div
              key={issue.id}
              className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between"
            >
              <div>
                <div className="relative h-48 rounded-2xl overflow-hidden mb-4 bg-slate-100 dark:bg-slate-800">
                  <img
                    src={issue.imageUrl}
                    alt={issue.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 left-3 flex gap-2">
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full shadow-md ${
                        issue.severity === 'critical'
                          ? 'bg-rose-600 text-white animate-pulse'
                          : issue.severity === 'high'
                          ? 'bg-orange-500 text-white'
                          : 'bg-slate-800 text-white'
                      }`}
                    >
                      {issue.severity} Severity
                    </span>
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full shadow-md ${
                        issue.status === 'resolved'
                          ? 'bg-emerald-600 text-white'
                          : issue.status === 'in_progress'
                          ? 'bg-amber-500 text-white'
                          : 'bg-blue-600 text-white'
                      }`}
                    >
                      {issue.status.replace('_', ' ')}
                    </span>
                  </div>
                </div>

                <h4 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2 line-clamp-1">
                  {issue.title}
                </h4>

                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                  {issue.description}
                </p>

                <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-4">
                  <MapPin className="w-3.5 h-3.5 text-rose-500 flex-shrink-0" />
                  <span className="truncate">{issue.location}, {issue.city}</span>
                </div>

                {/* Updates timeline snippet */}
                {issue.updates && issue.updates.length > 0 && (
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 mb-4">
                    <div className="text-[10px] font-bold uppercase text-slate-400 mb-1 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> Latest Civic Update
                    </div>
                    <div className="text-xs text-slate-700 dark:text-slate-200 font-medium">
                      "{issue.updates[issue.updates.length - 1].message}"
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">
                  Reported by {issue.reportedBy} ({issue.reportedAt})
                </span>

                <button
                  onClick={() => toggleUpvoteIssue(issue.id)}
                  className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl font-bold transition-all ${
                    issue.hasUpvoted
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200'
                  }`}
                >
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span>{issue.upvotes} Upvotes</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
