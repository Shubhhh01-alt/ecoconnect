export type IssueCategory = 'dumping' | 'water' | 'deforestation' | 'air' | 'wildlife' | 'sewage';
export type IssueSeverity = 'low' | 'medium' | 'high' | 'critical';
export type IssueStatus = 'reported' | 'in_review' | 'in_progress' | 'resolved';

export interface IssueUpdate {
  date: string;
  message: string;
  author: string;
}

export interface Issue {
  id: string;
  title: string;
  description: string;
  category: IssueCategory;
  severity: IssueSeverity;
  status: IssueStatus;
  location: string;
  city: string;
  reportedBy: string;
  reportedAt: string;
  imageUrl: string;
  upvotes: number;
  hasUpvoted?: boolean;
  resolvedAt?: string;
  updates: IssueUpdate[];
}

export type EventCategory = 'cleanup' | 'tree_planting' | 'food_drive' | 'water_action' | 'workshop';

export interface EcoEvent {
  id: string;
  title: string;
  description: string;
  category: EventCategory;
  date: string;
  time: string;
  location: string;
  city: string;
  organizer: string;
  organizerRole: string;
  spotsTotal: number;
  spotsFilled: number;
  rsvped: boolean;
  imageUrl: string;
  sdgBadge: 11 | 12 | 13 | 15;
}

export interface FoodDonation {
  id: string;
  donorName: string;
  donorType: 'Restaurant' | 'Hotel' | 'Bakery' | 'Community Kitchen' | 'Corporate' | 'Individual';
  title: string;
  quantity: string;
  mealsCount: number;
  foodType: 'Prepared Cooked' | 'Packaged Goods' | 'Bakery & Bread' | 'Fresh Produce' | 'Dry Groceries';
  pickupAddress: string;
  pickupWindow: string;
  status: 'available' | 'claimed' | 'picked_up';
  claimedBy?: string;
  createdAt: string;
  temperatureRequirement: 'Hot' | 'Chilled' | 'Room Temp';
}

export interface TreePledge {
  id: string;
  species: string;
  scientificName: string;
  plantedBy: string;
  location: string;
  date: string;
  co2PerYearKg: number;
  dedication?: string;
  treeIcon: string;
}

export interface WaterLeakReport {
  id: string;
  location: string;
  severity: 'Drip' | 'Steady Stream' | 'Burst Pipe / Flooding';
  reportedAt: string;
  estimatedLossLitersPerDay: number;
  status: 'Investigating' | 'Repair Dispatched' | 'Fixed';
}

export interface CommunityStory {
  id: string;
  author: string;
  role: string;
  avatar: string;
  content: string;
  imageUrl?: string;
  likes: number;
  liked?: boolean;
  tags: string[];
  timeAgo: string;
}

export interface EcoBadge {
  id: string;
  name: string;
  icon: string;
  unlocked: boolean;
  description: string;
  unlockedAt?: string;
}

export interface EcoUser {
  name: string;
  role: string;
  avatar: string;
  ecoPoints: number;
  level: string;
  badges: EcoBadge[];
  treesPlanted: number;
  cleanupHours: number;
  reportsSubmitted: number;
  mealsDonated: number;
}
