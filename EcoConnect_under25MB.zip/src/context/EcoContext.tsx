import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  Issue, 
  EcoEvent, 
  FoodDonation, 
  TreePledge, 
  WaterLeakReport, 
  CommunityStory, 
  EcoUser 
} from '../types';

export interface NotificationItem {
  id: string;
  message: string;
  type: 'success' | 'info' | 'warning';
  timestamp: string;
}

export interface EcoContextType {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  issues: Issue[];
  events: EcoEvent[];
  foodDonations: FoodDonation[];
  treePledges: TreePledge[];
  waterLeaks: WaterLeakReport[];
  communityStories: CommunityStory[];
  currentUser: EcoUser;
  notifications: NotificationItem[];
  addNotification: (message: string, type?: 'success' | 'info' | 'warning') => void;
  dismissNotification: (id: string) => void;
  addIssue: (issue: Omit<Issue, 'id' | 'reportedAt' | 'upvotes' | 'updates'>) => void;
  toggleUpvoteIssue: (id: string) => void;
  toggleEventRSVP: (eventId: string) => void;
  createEvent: (event: Omit<EcoEvent, 'id' | 'spotsFilled' | 'rsvped'>) => void;
  addFoodDonation: (donation: Omit<FoodDonation, 'id' | 'status' | 'createdAt'>) => void;
  claimFoodDonation: (id: string, ngoName: string) => void;
  pledgeTree: (tree: Omit<TreePledge, 'id' | 'date'>) => void;
  reportWaterLeak: (leak: Omit<WaterLeakReport, 'id' | 'reportedAt' | 'status'>) => void;
  toggleLikeStory: (storyId: string) => void;
  addCommunityStory: (content: string, tags: string[], imageUrl?: string) => void;
  awardPoints: (points: number, reason: string) => void;
  stats: {
    treesPlanted: number;
    mealsRescued: number;
    wasteDivertedTons: number;
    volunteersActive: number;
    issuesResolved: number;
    co2OffsetTons: number;
    waterSavedLiters: number;
  };
}

const INITIAL_ISSUES: Issue[] = [
  {
    id: 'iss-1',
    title: 'Illegal Plastic Waste Dumping on Lakeside Trail',
    description: 'Continuous dumping of single-use plastic crates, styrofoam boxes, and construction gravel choking the storm drainage feeding into Emerald Lake.',
    category: 'dumping',
    severity: 'high',
    status: 'in_progress',
    location: 'Emerald Lake Trail, Sector 4',
    city: 'Greenfield Metro',
    reportedBy: 'Maya Lin',
    reportedAt: '2 days ago',
    imageUrl: 'https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?auto=format&fit=crop&w=800&q=80',
    upvotes: 48,
    hasUpvoted: false,
    updates: [
      { date: 'Yesterday at 3 PM', message: 'Municipal sanitation alerted. 12 volunteers assigned for Saturday morning clearance.', author: 'EcoConnect Ops' }
    ]
  },
  {
    id: 'iss-2',
    title: 'Severe Sewage Overflow into North Canal Tributary',
    description: 'Blocked underground municipal drain causing raw untreated effluent overflow into pedestrian canal walkway.',
    category: 'sewage',
    severity: 'critical',
    status: 'reported',
    location: 'Willow Road Canal Crossing',
    city: 'Greenfield Metro',
    reportedBy: 'David Thorne',
    reportedAt: '5 hours ago',
    imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80',
    upvotes: 62,
    hasUpvoted: true,
    updates: [
      { date: '3 hours ago', message: 'Escalated to Public Health Board & Water Drainage Authority.', author: 'Civic Dispatcher' }
    ]
  },
  {
    id: 'iss-3',
    title: 'Unauthorized Midnight Smoke & Plastic Burning',
    description: 'Piles of industrial packing plastics set ablaze near elementary school boundary creating dense toxic smog.',
    category: 'air',
    severity: 'critical',
    status: 'in_review',
    location: 'Oakwood Primary Boundary Lane',
    city: 'Greenfield Metro',
    reportedBy: 'Priya Sharma',
    reportedAt: '1 day ago',
    imageUrl: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80',
    upvotes: 89,
    hasUpvoted: false,
    updates: []
  },
  {
    id: 'iss-4',
    title: 'Illegal Felling of 5 Mature Banyan Trees for Parking',
    description: 'Unpermitted logging of 40-year-old native shade canopy along public boulevard.',
    category: 'deforestation',
    severity: 'high',
    status: 'resolved',
    location: 'Hillview Avenue Boulevard',
    city: 'Greenfield Metro',
    reportedBy: 'Carlos Mendez',
    reportedAt: '1 week ago',
    resolvedAt: 'Yesterday',
    imageUrl: 'https://images.unsplash.com/photo-1511497584788-87676104235f?auto=format&fit=crop&w=800&q=80',
    upvotes: 142,
    hasUpvoted: true,
    updates: [
      { date: 'Yesterday', message: 'Stop-work legal injunction enforced. 40 compensatory native saplings planted!', author: 'Urban Canopy League' }
    ]
  }
];

const INITIAL_EVENTS: EcoEvent[] = [
  {
    id: 'evt-1',
    title: 'Great Emerald Lake & Wetland Restoration Blitz',
    description: 'Join over 120 community eco-warriors for deep cleanup and bio-waste removal along Emerald Lake wetlands. Free wading gear, gloves, and organic snacks provided.',
    category: 'cleanup',
    date: 'Saturday, Nov 28, 2026',
    time: '08:00 AM – 11:30 AM',
    location: 'Emerald Lake Park, North Pavilion',
    city: 'Greenfield Metro',
    organizer: 'Clean Lakes Alliance',
    organizerRole: 'Regional Watershed NGO',
    spotsTotal: 150,
    spotsFilled: 118,
    rsvped: true,
    imageUrl: 'https://images.unsplash.com/photo-1559827291-72ee739d0d9a?auto=format&fit=crop&w=800&q=80',
    sdgBadge: 11
  },
  {
    id: 'evt-2',
    title: 'Urban Canopy 500: Miyawaki Forest Plantation',
    description: 'Planting 500 indigenous saplings using the rapid Miyawaki method to create an urban biodiversity haven and cool street microclimates.',
    category: 'tree_planting',
    date: 'Sunday, Nov 29, 2026',
    time: '08:30 AM – 12:30 PM',
    location: 'Greenfield Sector 9 Bio-Belt',
    city: 'Greenfield Metro',
    organizer: 'Canopy for Future',
    organizerRole: 'Botanical Conservation Foundation',
    spotsTotal: 90,
    spotsFilled: 74,
    rsvped: false,
    imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80',
    sdgBadge: 15
  },
  {
    id: 'evt-3',
    title: 'Surplus Banquet Food Rescue Express',
    description: 'Collect packaged surplus meals and bakery crates from weekend convention galas and deliver them to 3 community shelters in 90 minutes.',
    category: 'food_drive',
    date: 'Friday, Dec 4, 2026',
    time: '05:30 PM – 08:30 PM',
    location: 'Metro Central Logistics Dock 4',
    city: 'Greenfield Metro',
    organizer: 'Zero Hunger Network',
    organizerRole: 'Community Relief Team',
    spotsTotal: 40,
    spotsFilled: 29,
    rsvped: false,
    imageUrl: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=800&q=80',
    sdgBadge: 12
  },
  {
    id: 'evt-4',
    title: 'DIY Rainwater Harvesting & Greywater Workshop',
    description: 'Hands-on practical session showing homeowners and tenant associations how to install modular roof catchment barrels and gravity filtration.',
    category: 'workshop',
    date: 'Saturday, Dec 5, 2026',
    time: '10:00 AM – 01:00 PM',
    location: 'Community Science Center, Lab 2',
    city: 'Greenfield Metro',
    organizer: 'WaterWise Lab',
    organizerRole: 'Ecological Engineering Group',
    spotsTotal: 60,
    spotsFilled: 51,
    rsvped: false,
    imageUrl: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=800&q=80',
    sdgBadge: 13
  }
];

const INITIAL_FOOD_DONATIONS: FoodDonation[] = [
  {
    id: 'fd-1',
    donorName: 'The Grand Zenith Hotel & Suites',
    donorType: 'Hotel',
    title: '85 Packaged Gourmet Bento Boxes (Halal & Veg Options)',
    quantity: '85 boxed meals',
    mealsCount: 85,
    foodType: 'Prepared Cooked',
    pickupAddress: '450 Skyline Boulevard, Loading Bay B',
    pickupWindow: 'Today 2:00 PM – 5:30 PM',
    status: 'available',
    createdAt: '40 mins ago',
    temperatureRequirement: 'Chilled'
  },
  {
    id: 'fd-2',
    donorName: 'Golden Crust Boulangerie',
    donorType: 'Bakery',
    title: '140 Artisan Sourdough Loaves, Croissants & Baguettes',
    quantity: '6 crates',
    mealsCount: 140,
    foodType: 'Bakery & Bread',
    pickupAddress: '18 Market Street, Old Town',
    pickupWindow: 'Today 6:00 PM – 8:00 PM',
    status: 'available',
    createdAt: '1 hour ago',
    temperatureRequirement: 'Room Temp'
  },
  {
    id: 'fd-3',
    donorName: 'Sunrise Cooperative Supermarket',
    donorType: 'Corporate',
    title: '220 kg Farm-Fresh Surplus Apples, Pears & Greens',
    quantity: '12 crates (220 kg)',
    mealsCount: 180,
    foodType: 'Fresh Produce',
    pickupAddress: '88 Valley Road, West End',
    pickupWindow: 'Tomorrow 9:00 AM – 1:00 PM',
    status: 'claimed',
    claimedBy: 'Hope Harbor Community Kitchen',
    createdAt: '3 hours ago',
    temperatureRequirement: 'Room Temp'
  }
];

const INITIAL_TREES: TreePledge[] = [
  {
    id: 'tp-1',
    species: 'Neem Tree (Azadirachta Indica)',
    scientificName: 'Azadirachta indica',
    plantedBy: 'Samantha Green',
    location: 'North Ridge Community Forest, Plot A-12',
    date: 'Nov 14, 2026',
    co2PerYearKg: 28,
    dedication: 'In memory of Grandma Clara, champion of wild songbirds',
    treeIcon: '🌳'
  },
  {
    id: 'tp-2',
    species: 'Coast Live Oak (Quercus Agrifolia)',
    scientificName: 'Quercus agrifolia',
    plantedBy: 'Alex Rivera',
    location: 'Civic Central Park, Sector 9 Bio-Belt',
    date: 'Nov 18, 2026',
    co2PerYearKg: 35,
    dedication: 'For cleaner air for our kids',
    treeIcon: '🌲'
  },
  {
    id: 'tp-3',
    species: 'Royal Gulmohar / Flamboyant',
    scientificName: 'Delonix regia',
    plantedBy: 'Greenfield High School EcoClub',
    location: 'School Perimeter Greenway',
    date: 'Nov 20, 2026',
    co2PerYearKg: 24,
    dedication: 'Graduating Class of 2026 Earth Pledge',
    treeIcon: '🌱'
  }
];

const INITIAL_LEAKS: WaterLeakReport[] = [
  {
    id: 'wl-1',
    location: 'Corner of 4th Ave & Pine Street, near Fire Hydrant 12',
    severity: 'Steady Stream',
    reportedAt: '1 day ago',
    estimatedLossLitersPerDay: 4800,
    status: 'Repair Dispatched'
  },
  {
    id: 'wl-2',
    location: 'Central Park North Fountain Supply Pipe',
    severity: 'Drip',
    reportedAt: '3 days ago',
    estimatedLossLitersPerDay: 450,
    status: 'Investigating'
  },
  {
    id: 'wl-3',
    location: 'Market Street Commercial Alley Main Valve',
    severity: 'Burst Pipe / Flooding',
    reportedAt: '4 days ago',
    estimatedLossLitersPerDay: 18000,
    status: 'Fixed'
  }
];

const INITIAL_STORIES: CommunityStory[] = [
  {
    id: 'cs-1',
    author: 'Sunita Patel',
    role: 'Ward 12 Community Organizer',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80',
    content: 'How 80 neighbors transformed an abandoned 2-acre hazardous wasteland littered with 18 tons of industrial rubble into a flourishing community pollinator orchard using Miyawaki planting!',
    imageUrl: 'https://images.unsplash.com/photo-1588880331179-bc9b93a8cb5e?auto=format&fit=crop&w=800&q=80',
    likes: 174,
    liked: true,
    tags: ['Urban Forestry', 'Zero Waste', 'Before & After'],
    timeAgo: '2 days ago'
  },
  {
    id: 'cs-2',
    author: 'Chef Jean-Luc Moreau',
    role: 'Executive Chef & Food Rescue Pioneer',
    avatar: 'https://images.unsplash.com/photo-1583394293214-28ded15ee548?auto=format&fit=crop&w=150&q=80',
    content: 'Instead of throwing away 40kg of gourmet wedding banquet food, our team listed it on EcoConnect. In 25 minutes, volunteer drivers arrived and 120 nutritious warm meals were served to families at Hope Harbor.',
    imageUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80',
    likes: 231,
    liked: false,
    tags: ['Food Rescue', 'Zero Hunger', 'Civic Action'],
    timeAgo: '4 days ago'
  }
];

const INITIAL_USER: EcoUser = {
  name: 'Alex Rivera',
  role: 'Community Eco-Advocate',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
  ecoPoints: 340,
  level: 'Forest Guardian (Level 3)',
  treesPlanted: 6,
  cleanupHours: 18,
  reportsSubmitted: 4,
  mealsDonated: 120,
  badges: [
    { id: 'b1', name: 'First Cleanup Hero', icon: '🧹', unlocked: true, description: 'Joined first civic clean-up drive', unlockedAt: 'Oct 2026' },
    { id: 'b2', name: 'Certified Tree Parent', icon: '🌳', unlocked: true, description: 'Pledged and nurtured native sapling', unlockedAt: 'Nov 2026' },
    { id: 'b3', name: 'Zero-Waste Champion', icon: '♻️', unlocked: true, description: 'Diverted over 50kg household waste', unlockedAt: 'Nov 2026' },
    { id: 'b4', name: 'River Watcher', icon: '💧', unlocked: true, description: 'Reported water pollution incident', unlockedAt: 'Nov 2026' },
    { id: 'b5', name: 'Food Rescue Runner', icon: '🍲', unlocked: false, description: 'Complete 3 surplus food pickups' }
  ]
};

const EcoContext = createContext<EcoContextType | undefined>(undefined);

export const EcoProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    return (localStorage.getItem('ecoconnect_theme') as 'light' | 'dark') || 'light';
  });

  const [issues, setIssues] = useState<Issue[]>(() => {
    const saved = localStorage.getItem('ecoconnect_issues');
    return saved ? JSON.parse(saved) : INITIAL_ISSUES;
  });

  const [events, setEvents] = useState<EcoEvent[]>(() => {
    const saved = localStorage.getItem('ecoconnect_events');
    return saved ? JSON.parse(saved) : INITIAL_EVENTS;
  });

  const [foodDonations, setFoodDonations] = useState<FoodDonation[]>(() => {
    const saved = localStorage.getItem('ecoconnect_food');
    return saved ? JSON.parse(saved) : INITIAL_FOOD_DONATIONS;
  });

  const [treePledges, setTreePledges] = useState<TreePledge[]>(() => {
    const saved = localStorage.getItem('ecoconnect_trees');
    return saved ? JSON.parse(saved) : INITIAL_TREES;
  });

  const [waterLeaks, setWaterLeaks] = useState<WaterLeakReport[]>(() => {
    const saved = localStorage.getItem('ecoconnect_leaks');
    return saved ? JSON.parse(saved) : INITIAL_LEAKS;
  });

  const [communityStories, setCommunityStories] = useState<CommunityStory[]>(() => {
    const saved = localStorage.getItem('ecoconnect_stories');
    return saved ? JSON.parse(saved) : INITIAL_STORIES;
  });

  const [currentUser, setCurrentUser] = useState<EcoUser>(() => {
    const saved = localStorage.getItem('ecoconnect_user');
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'n-1',
      message: 'Welcome to EcoConnect! Earn points by reporting issues or joining cleanups.',
      type: 'info',
      timestamp: 'Just now'
    }
  ]);

  // Sync theme
  useEffect(() => {
    localStorage.setItem('ecoconnect_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Sync storage
  useEffect(() => { localStorage.setItem('ecoconnect_issues', JSON.stringify(issues)); }, [issues]);
  useEffect(() => { localStorage.setItem('ecoconnect_events', JSON.stringify(events)); }, [events]);
  useEffect(() => { localStorage.setItem('ecoconnect_food', JSON.stringify(foodDonations)); }, [foodDonations]);
  useEffect(() => { localStorage.setItem('ecoconnect_trees', JSON.stringify(treePledges)); }, [treePledges]);
  useEffect(() => { localStorage.setItem('ecoconnect_leaks', JSON.stringify(waterLeaks)); }, [waterLeaks]);
  useEffect(() => { localStorage.setItem('ecoconnect_stories', JSON.stringify(communityStories)); }, [communityStories]);
  useEffect(() => { localStorage.setItem('ecoconnect_user', JSON.stringify(currentUser)); }, [currentUser]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const addNotification = (message: string, type: 'success' | 'info' | 'warning' = 'info') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setNotifications((prev) => [{ id, message, type, timestamp: 'Just now' }, ...prev.slice(0, 5)]);
    setTimeout(() => {
      dismissNotification(id);
    }, 5000);
  };

  const dismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const awardPoints = (points: number, reason: string) => {
    setCurrentUser((prev) => ({
      ...prev,
      ecoPoints: prev.ecoPoints + points
    }));
    addNotification(`+${points} Eco-Points rewarded for: ${reason}!`, 'success');
    confetti({
      particleCount: 60,
      spread: 60,
      origin: { y: 0.7 },
      colors: ['#22c55e', '#16a34a', '#fbbf24', '#38bdf8']
    });
  };

  const addIssue = (newIssue: Omit<Issue, 'id' | 'reportedAt' | 'upvotes' | 'updates'>) => {
    const id = `iss-${Date.now().toString().slice(-4)}`;
    const issueWithMeta: Issue = {
      ...newIssue,
      id,
      reportedAt: 'Just now',
      upvotes: 1,
      hasUpvoted: true,
      updates: [
        { date: 'Just now', message: 'Report registered in public docket. Dispatched alert to Municipal Ward Officer.', author: 'EcoConnect Citizen Dispatch' }
      ]
    };
    setIssues((prev) => [issueWithMeta, ...prev]);
    setCurrentUser((prev) => ({ ...prev, reportsSubmitted: prev.reportsSubmitted + 1 }));
    awardPoints(50, 'Filing an environmental incident report');
  };

  const toggleUpvoteIssue = (id: string) => {
    setIssues((prev) =>
      prev.map((iss) => {
        if (iss.id === id) {
          const isUpvoted = iss.hasUpvoted;
          return {
            ...iss,
            upvotes: isUpvoted ? iss.upvotes - 1 : iss.upvotes + 1,
            hasUpvoted: !isUpvoted
          };
        }
        return iss;
      })
    );
    addNotification('Priority signal updated. Your verification assists municipal triage.', 'info');
  };

  const toggleEventRSVP = (eventId: string) => {
    setEvents((prev) =>
      prev.map((evt) => {
        if (evt.id === eventId) {
          const newRsvped = !evt.rsvped;
          return {
            ...evt,
            rsvped: newRsvped,
            spotsFilled: newRsvped ? evt.spotsFilled + 1 : Math.max(0, evt.spotsFilled - 1)
          };
        }
        return evt;
      })
    );
    awardPoints(30, 'Confirming volunteer event RSVP');
  };

  const createEvent = (eventData: Omit<EcoEvent, 'id' | 'spotsFilled' | 'rsvped'>) => {
    const newId = `evt-${Date.now().toString().slice(-4)}`;
    const newEvt: EcoEvent = {
      ...eventData,
      id: newId,
      spotsFilled: 1,
      rsvped: true
    };
    setEvents((prev) => [newEvt, ...prev]);
    awardPoints(100, 'Hosting a community environmental event');
  };

  const addFoodDonation = (donationData: Omit<FoodDonation, 'id' | 'status' | 'createdAt'>) => {
    const newId = `fd-${Date.now().toString().slice(-4)}`;
    const item: FoodDonation = {
      ...donationData,
      id: newId,
      status: 'available',
      createdAt: 'Just now'
    };
    setFoodDonations((prev) => [item, ...prev]);
    setCurrentUser((prev) => ({ ...prev, mealsDonated: prev.mealsDonated + item.mealsCount }));
    awardPoints(60, 'Listing surplus meals for hunger relief');
  };

  const claimFoodDonation = (id: string, ngoName: string) => {
    setFoodDonations((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return { ...item, status: 'claimed', claimedBy: ngoName };
        }
        return item;
      })
    );
    awardPoints(40, 'Claiming and distributing rescued food to shelters');
  };

  const pledgeTree = (treeData: Omit<TreePledge, 'id' | 'date'>) => {
    const newId = `tp-${Date.now().toString().slice(-4)}`;
    const newTree: TreePledge = {
      ...treeData,
      id: newId,
      date: 'Just now'
    };
    setTreePledges((prev) => [newTree, ...prev]);
    setCurrentUser((prev) => ({ ...prev, treesPlanted: prev.treesPlanted + 1 }));
    awardPoints(100, 'Adopting and planting a native sapling');
  };

  const reportWaterLeak = (leakData: Omit<WaterLeakReport, 'id' | 'reportedAt' | 'status'>) => {
    const newId = `wl-${Date.now().toString().slice(-4)}`;
    const newLeak: WaterLeakReport = {
      ...leakData,
      id: newId,
      reportedAt: 'Just now',
      status: 'Investigating'
    };
    setWaterLeaks((prev) => [newLeak, ...prev]);
    awardPoints(50, 'Reporting a freshwater pipeline leak');
  };

  const toggleLikeStory = (storyId: string) => {
    setCommunityStories((prev) =>
      prev.map((s) => {
        if (s.id === storyId) {
          const isLiked = s.liked;
          return {
            ...s,
            likes: isLiked ? s.likes - 1 : s.likes + 1,
            liked: !isLiked
          };
        }
        return s;
      })
    );
  };

  const addCommunityStory = (content: string, tags: string[], imageUrl?: string) => {
    const newId = `cs-${Date.now().toString().slice(-4)}`;
    const story: CommunityStory = {
      id: newId,
      author: currentUser.name,
      role: currentUser.role,
      avatar: currentUser.avatar,
      content,
      imageUrl: imageUrl || 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80',
      likes: 1,
      liked: true,
      tags: tags.length > 0 ? tags : ['Grassroots Action'],
      timeAgo: 'Just now'
    };
    setCommunityStories((prev) => [story, ...prev]);
    awardPoints(25, 'Sharing a community impact story');
  };

  const stats = {
    treesPlanted: 148920 + treePledges.length,
    mealsRescued: 89450 + foodDonations.reduce((acc, curr) => acc + curr.mealsCount, 0),
    wasteDivertedTons: 540 + Math.floor(issues.filter(i => i.status === 'resolved').length * 2.5),
    volunteersActive: 32400 + events.reduce((acc, curr) => acc + curr.spotsFilled, 0),
    issuesResolved: issues.filter((i) => i.status === 'resolved').length,
    co2OffsetTons: 1420 + Math.floor(treePledges.length * 0.05),
    waterSavedLiters: 1250000 + waterLeaks.filter(l => l.status === 'Fixed').length * 15000
  };

  return (
    <EcoContext.Provider
      value={{
        theme,
        toggleTheme,
        issues,
        events,
        foodDonations,
        treePledges,
        waterLeaks,
        communityStories,
        currentUser,
        notifications,
        addNotification,
        dismissNotification,
        addIssue,
        toggleUpvoteIssue,
        toggleEventRSVP,
        createEvent,
        addFoodDonation,
        claimFoodDonation,
        pledgeTree,
        reportWaterLeak,
        toggleLikeStory,
        addCommunityStory,
        awardPoints,
        stats
      }}
    >
      {children}
    </EcoContext.Provider>
  );
};

export const useEco = () => {
  const context = useContext(EcoContext);
  if (!context) {
    throw new Error('useEco must be used within an EcoProvider');
  }
  return context;
};
