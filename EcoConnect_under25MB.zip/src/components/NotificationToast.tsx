import React from 'react';
import { useEco } from '../context/EcoContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export const NotificationToast: React.FC = () => {
  const { notifications, dismissNotification } = useEco();

  if (notifications.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col space-y-2 max-w-sm w-full pointer-events-none">
      {notifications.slice(0, 3).map(notif => (
        <div
          key={notif.id}
          className={`pointer-events-auto flex items-start gap-3 p-3.5 rounded-xl shadow-xl border backdrop-blur-md transition-all duration-300 animate-in slide-in-from-bottom-2 ${
            notif.type === 'success'
              ? 'bg-emerald-900/90 text-emerald-100 border-emerald-500/40'
              : notif.type === 'warning'
              ? 'bg-amber-900/90 text-amber-100 border-amber-500/40'
              : 'bg-slate-900/90 text-slate-100 border-slate-700/60'
          }`}
        >
          <div className="mt-0.5 flex-shrink-0">
            {notif.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
            {notif.type === 'warning' && <AlertCircle className="w-5 h-5 text-amber-400" />}
            {notif.type === 'info' && <Info className="w-5 h-5 text-sky-400" />}
          </div>
          <div className="flex-1 text-xs sm:text-sm font-medium leading-snug">
            {notif.message}
            <div className="text-[10px] text-white/60 mt-1">{notif.timestamp}</div>
          </div>
          <button
            onClick={() => dismissNotification(notif.id)}
            className="text-white/60 hover:text-white transition-colors p-1"
            title="Dismiss notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
