import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Sprout, 
  ChevronDown, 
  Sun, 
  Moon, 
  Bell, 
  AlertTriangle, 
  Menu, 
  X, 
  Trees, 
  UtensilsCrossed, 
  Droplet, 
  Trash2, 
  Award,
  Sparkles,
  BarChart3,
  Users2,
  Calendar,
  Info,
  PhoneCall
} from 'lucide-react';
import { useEco } from '../context/EcoContext';

export const Navbar: React.FC = () => {
  const { theme, toggleTheme, notifications, currentUser, dismissNotification } = useEco();
  const [initiativesOpen, setInitiativesOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const dropdownRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  // Close menus on route change
  useEffect(() => {
    setInitiativesOpen(false);
    setMobileMenuOpen(false);
    setNotifDropdownOpen(false);
  }, [location.pathname]);

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Click outside listener for dropdowns
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setInitiativesOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const initiatives = [
    {
      title: 'Tree Plantation Drives',
      desc: 'Pledge native saplings & grow the community forest',
      path: '/initiatives/tree-plantation',
      icon: Trees,
      color: 'text-emerald-500 bg-emerald-500/10'
    },
    {
      title: 'Surplus Food Rescue',
      desc: 'Bridge banquet surplus with shelters & stop waste',
      path: '/initiatives/food-rescue',
      icon: UtensilsCrossed,
      color: 'text-amber-500 bg-amber-500/10'
    },
    {
      title: 'Water Conservation Hub',
      desc: 'Water footprint audits, leak reporting & savings',
      path: '/initiatives/water-conservation',
      icon: Droplet,
      color: 'text-sky-500 bg-sky-500/10'
    },
    {
      title: 'Clean-up Drives & Waste',
      desc: 'Beach & park cleanups, segregation guides',
      path: '/initiatives/clean-up',
      icon: Trash2,
      color: 'text-teal-500 bg-teal-500/10'
    }
  ];

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        scrolled
          ? 'bg-white/90 dark:bg-slate-950/90 backdrop-blur-md shadow-sm border-b border-slate-200/80 dark:border-slate-800/80 py-3'
          : 'bg-white/80 dark:bg-slate-950/80 backdrop-blur-sm border-b border-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-md shadow-emerald-500/25 group-hover:scale-105 transition-transform">
              <Sprout className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-black tracking-tight text-slate-900 dark:text-white">
                  Eco<span className="text-eco-600 dark:text-eco-400">Connect</span>
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-eco-100 dark:bg-eco-900/60 text-eco-800 dark:text-eco-300">
                  SDGs
                </span>
              </div>
              <p className="text-[10px] font-medium text-slate-500 dark:text-slate-400 -mt-0.5 hidden sm:block">
                Action for People & Planet
              </p>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
            <Link
              to="/"
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                isActive('/') && location.pathname === '/'
                  ? 'text-eco-600 dark:text-eco-400 bg-eco-50 dark:bg-eco-950/60'
                  : 'text-slate-600 dark:text-slate-300 hover:text-eco-600 dark:hover:text-eco-400 hover:bg-slate-50 dark:hover:bg-slate-900/60'
              }`}
            >
              Home
            </Link>

            {/* Initiatives Dropdown */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setInitiativesOpen(!initiativesOpen)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                  isActive('/initiatives')
                    ? 'text-eco-600 dark:text-eco-400 bg-eco-50 dark:bg-eco-950/60'
                    : 'text-slate-600 dark:text-slate-300 hover:text-eco-600 dark:hover:text-eco-400 hover:bg-slate-50 dark:hover:bg-slate-900/60'
                }`}
              >
                <span>Explore Initiatives</span>
                <ChevronDown
                  className={`w-4 h-4 transition-transform duration-200 ${
                    initiativesOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {initiativesOpen && (
                <div className="absolute top-full left-0 mt-2 w-80 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-2.5 animate-in fade-in slide-in-from-top-2">
                  <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    Active SDG Initiatives
                  </div>
                  <div className="space-y-1">
                    {initiatives.map(item => {
                      const Icon = item.icon;
                      return (
                        <Link
                          key={item.path}
                          to={item.path}
                          onClick={() => setInitiativesOpen(false)}
                          className={`flex items-start gap-3 p-2.5 rounded-xl transition-all ${
                            location.pathname === item.path
                              ? 'bg-eco-50 dark:bg-eco-950/70 border border-eco-500/20'
                              : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
                          }`}
                        >
                          <div className={`p-2 rounded-lg ${item.color} flex-shrink-0 mt-0.5`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-sm font-bold text-slate-800 dark:text-slate-100">
                              {item.title}
                            </div>
                            <div className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                              {item.desc}
                            </div>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            <Link
              to="/report"
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
                isActive('/report')
                  ? 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60'
                  : 'text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-50 dark:hover:bg-slate-900/60'
              }`}
            >
              <AlertTriangle className="w-4 h-4 text-rose-500" />
              <span>Report Issue</span>
            </Link>

            <Link
              to="/events"
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
                isActive('/events')
                  ? 'text-eco-600 dark:text-eco-400 bg-eco-50 dark:bg-eco-950/60'
                  : 'text-slate-600 dark:text-slate-300 hover:text-eco-600 dark:hover:text-eco-400 hover:bg-slate-50 dark:hover:bg-slate-900/60'
              }`}
            >
              <Calendar className="w-4 h-4 text-emerald-500" />
              <span>Events</span>
            </Link>

            <Link
              to="/impact"
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
                isActive('/impact')
                  ? 'text-eco-600 dark:text-eco-400 bg-eco-50 dark:bg-eco-950/60'
                  : 'text-slate-600 dark:text-slate-300 hover:text-eco-600 dark:hover:text-eco-400 hover:bg-slate-50 dark:hover:bg-slate-900/60'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-teal-500" />
              <span>Impact</span>
            </Link>

            <Link
              to="/community"
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
                isActive('/community')
                  ? 'text-eco-600 dark:text-eco-400 bg-eco-50 dark:bg-eco-950/60'
                  : 'text-slate-600 dark:text-slate-300 hover:text-eco-600 dark:hover:text-eco-400 hover:bg-slate-50 dark:hover:bg-slate-900/60'
              }`}
            >
              <Users2 className="w-4 h-4 text-indigo-500" />
              <span>Community</span>
            </Link>

            <Link
              to="/about"
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                isActive('/about')
                  ? 'text-eco-600 dark:text-eco-400 bg-eco-50 dark:bg-eco-950/60'
                  : 'text-slate-600 dark:text-slate-300 hover:text-eco-600 dark:hover:text-eco-400 hover:bg-slate-50 dark:hover:bg-slate-900/60'
              }`}
            >
              About & SDGs
            </Link>

            <Link
              to="/contact"
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                isActive('/contact')
                  ? 'text-eco-600 dark:text-eco-400 bg-eco-50 dark:bg-eco-950/60'
                  : 'text-slate-600 dark:text-slate-300 hover:text-eco-600 dark:hover:text-eco-400 hover:bg-slate-50 dark:hover:bg-slate-900/60'
              }`}
            >
              Contact
            </Link>
          </nav>

          {/* Right Action Bar */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Theme Toggle Button */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-600" />}
            </button>

            {/* Notifications Bell */}
            <div className="relative" ref={notifRef}>
              <button
                onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
                className="relative p-2 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                aria-label="View notifications"
              >
                <Bell className="w-5 h-5" />
                {notifications.length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900 animate-pulse" />
                )}
              </button>

              {notifDropdownOpen && (
                <div className="absolute right-0 mt-2 w-80 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-3 animate-in fade-in slide-in-from-top-2 z-50">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      Live Eco Updates ({notifications.length})
                    </span>
                    <span className="text-[10px] text-eco-600 dark:text-eco-400 font-semibold">
                      Real-time Feed
                    </span>
                  </div>
                  <div className="space-y-2 max-h-72 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <p className="text-xs text-slate-400 text-center py-4">No new notifications</p>
                    ) : (
                      notifications.map(n => (
                        <div
                          key={n.id}
                          className="flex items-start justify-between gap-2 p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60 text-xs"
                        >
                          <div>
                            <p className="text-slate-800 dark:text-slate-200 font-medium">{n.message}</p>
                            <span className="text-[10px] text-slate-400">{n.timestamp}</span>
                          </div>
                          <button
                            onClick={() => dismissNotification(n.id)}
                            className="text-slate-400 hover:text-slate-600 p-0.5"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* User Points Badge */}
            <Link
              to="/community"
              className="hidden md:flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 hover:border-eco-500/50 transition-colors"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-6 h-6 rounded-full object-cover ring-1 ring-eco-500"
              />
              <div className="flex items-center gap-1 text-xs font-bold text-slate-800 dark:text-slate-200">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>{currentUser.ecoPoints}</span>
                <span className="text-[10px] text-slate-400 font-medium">pts</span>
              </div>
            </Link>

            {/* Quick Action Button */}
            <Link
              to="/report"
              className="inline-flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-emerald-600/25 transition-all active:scale-95"
            >
              <AlertTriangle className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-200" />
              <span className="hidden xs:inline">Report Issue</span>
              <span className="xs:hidden">Report</span>
            </Link>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-3 pt-3 border-t border-slate-200 dark:border-slate-800 pb-4 space-y-2 animate-in fade-in slide-in-from-top-2">
            <Link
              to="/"
              className={`block px-3 py-2 rounded-lg text-sm font-semibold ${
                location.pathname === '/'
                  ? 'bg-eco-50 dark:bg-eco-950/60 text-eco-600 dark:text-eco-400'
                  : 'text-slate-700 dark:text-slate-200'
              }`}
            >
              Home
            </Link>

            <div className="px-3 py-1">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Initiatives
              </span>
              <div className="mt-1 pl-2 space-y-1">
                {initiatives.map(item => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className="block py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-eco-600 dark:hover:text-eco-400"
                  >
                    • {item.title}
                  </Link>
                ))}
              </div>
            </div>

            <Link
              to="/report"
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold text-rose-600 dark:text-rose-400"
            >
              <AlertTriangle className="w-4 h-4" />
              Report Environmental Issue
            </Link>

            <Link
              to="/events"
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold text-slate-700 dark:text-slate-200"
            >
              <Calendar className="w-4 h-4 text-emerald-500" />
              Community Events
            </Link>

            <Link
              to="/impact"
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold text-slate-700 dark:text-slate-200"
            >
              <BarChart3 className="w-4 h-4 text-teal-500" />
              Impact Analytics
            </Link>

            <Link
              to="/community"
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold text-slate-700 dark:text-slate-200"
            >
              <Users2 className="w-4 h-4 text-indigo-500" />
              Community Hub & Leaderboard
            </Link>

            <Link
              to="/about"
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold text-slate-700 dark:text-slate-200"
            >
              <Info className="w-4 h-4 text-slate-500" />
              About Us & SDGs
            </Link>

            <Link
              to="/contact"
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold text-slate-700 dark:text-slate-200"
            >
              <PhoneCall className="w-4 h-4 text-slate-500" />
              Contact & Support
            </Link>

            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between px-3">
              <div className="flex items-center gap-2">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-7 h-7 rounded-full object-cover"
                />
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  {currentUser.name}
                </span>
              </div>
              <span className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> {currentUser.ecoPoints} pts
              </span>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
