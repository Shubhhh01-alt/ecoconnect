import React, { useState } from 'react';
import { Building2, RefreshCw, Flame, Trees, ArrowUpRight, CheckCircle, Target, X } from 'lucide-react';

export interface SDGInfo {
  number: 11 | 12 | 13 | 15;
  title: string;
  subtitle: string;
  color: string;
  bgLight: string;
  icon: any;
  targetFocus: string;
  ourImpact: string;
  keyTargets: string[];
  linkRoute: string;
}

export const sdgData: SDGInfo[] = [
  {
    number: 11,
    title: 'Sustainable Cities & Communities',
    subtitle: 'Make cities and human settlements inclusive, safe, resilient, and sustainable.',
    color: '#FD9D24',
    bgLight: 'from-amber-500/10 to-orange-500/10 border-orange-500/30',
    icon: Building2,
    targetFocus: 'Target 11.6: Reduce adverse per capita environmental impact of cities (air & waste).',
    ourImpact: '1,840+ municipal hazard reports resolved and 215+ tons of waste prevented from clogging urban waterways.',
    keyTargets: [
      'Empowering citizens to report localized environmental degradation to city authorities',
      'Revitalizing urban green spaces and micro-wetlands',
      'Promoting community-level decentralized disaster resilience'
    ],
    linkRoute: '/report'
  },
  {
    number: 12,
    title: 'Responsible Consumption & Production',
    subtitle: 'Ensure sustainable consumption and production patterns through waste reduction & surplus reuse.',
    color: '#CF8D2A',
    bgLight: 'from-yellow-500/10 to-amber-500/10 border-amber-500/30',
    icon: RefreshCw,
    targetFocus: 'Target 12.3: Halve per capita global food waste & reduce food loss across supply chains.',
    ourImpact: '86,400+ fresh meals rescued from banquets and markets, feeding vulnerable families instead of generating methane in landfills.',
    keyTargets: [
      'Bridging event banquet surplus with verified community shelters',
      'Promoting zero-waste circular neighborhood segregation systems',
      'Real-time food rescue dispatch reducing municipal organic waste'
    ],
    linkRoute: '/initiatives/food-rescue'
  },
  {
    number: 13,
    title: 'Climate Action',
    subtitle: 'Take urgent action to combat climate change and its impacts through grassroots mitigation.',
    color: '#3F7E44',
    bgLight: 'from-emerald-600/10 to-green-700/10 border-emerald-600/30',
    icon: Flame,
    targetFocus: 'Target 13.3: Improve education, awareness-raising, and human capacity on climate mitigation.',
    ourImpact: '3,420+ tons CO2 sequestered and 34,200+ trained volunteers mobilizing across local watersheds and climate strikes.',
    keyTargets: [
      'Interactive household water & carbon footprint audits with personalized reduction blueprints',
      'Community leak mitigation preserving vital municipal freshwater reservoirs',
      'Grassroots climate literacy and community response squads'
    ],
    linkRoute: '/initiatives/water-conservation'
  },
  {
    number: 15,
    title: 'Life on Land',
    subtitle: 'Protect, restore and promote sustainable use of terrestrial ecosystems, forests and halt biodiversity loss.',
    color: '#56C02B',
    bgLight: 'from-lime-500/10 to-green-600/10 border-lime-500/30',
    icon: Trees,
    targetFocus: 'Target 15.2: Promote sustainable management of all forests and halt deforestation.',
    ourImpact: '142,850+ native Miyawaki trees planted across degraded buffer corridors with an 89% 2-year survival tracking rate.',
    keyTargets: [
      'Pledge and geotag native biodiversity trees with ongoing canopy tracking',
      'Restoring degraded urban buffers and micro-corridors',
      'Citizen vigil against illegal felling of protected heritage canopies'
    ],
    linkRoute: '/initiatives/tree-plantation'
  }
];

export const SDGCard: React.FC<{ sdg: SDGInfo; onClick?: () => void }> = ({ sdg }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const Icon = sdg.icon;

  return (
    <>
      <div 
        onClick={() => setModalOpen(true)}
        className="group relative rounded-2xl p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-eco-500/50 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between overflow-hidden"
      >
        {/* Subtle accent corner glow */}
        <div 
          className="absolute -top-12 -right-12 w-32 h-32 rounded-full opacity-15 blur-2xl group-hover:opacity-30 transition-opacity"
          style={{ backgroundColor: sdg.color }}
        />

        <div>
          {/* Top SDG Badge header */}
          <div className="flex items-center justify-between mb-4">
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center font-black text-white text-lg shadow-md"
              style={{ backgroundColor: sdg.color }}
            >
              {sdg.number}
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center gap-1 group-hover:text-eco-600 dark:group-hover:text-eco-400 transition-colors">
              Explore Target <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </span>
          </div>

          <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-eco-600 dark:group-hover:text-eco-400 transition-colors">
            {sdg.title}
          </h3>

          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 line-clamp-2 mb-4 leading-relaxed">
            {sdg.subtitle}
          </p>
        </div>

        <div className="pt-4 border-t border-slate-100 dark:border-slate-800/80">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
            EcoConnect Field Impact
          </div>
          <div className="text-xs text-slate-700 dark:text-slate-200 font-medium line-clamp-2">
            {sdg.ourImpact}
          </div>
        </div>
      </div>

      {/* Modal View */}
      {modalOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in"
          onClick={() => setModalOpen(false)}
        >
          <div 
            className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 dark:border-slate-800"
            onClick={e => e.stopPropagation()}
          >
            <button
              onClick={() => setModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-4 mb-6">
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center font-black text-white text-2xl shadow-lg"
                style={{ backgroundColor: sdg.color }}
              >
                {sdg.number}
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-eco-600 dark:text-eco-400">
                  UN Sustainable Development Goal
                </span>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white">
                  {sdg.title}
                </h3>
              </div>
            </div>

            <p className="text-slate-600 dark:text-slate-300 mb-6 leading-relaxed text-sm sm:text-base">
              {sdg.subtitle}
            </p>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 mb-6">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
                <Target className="w-4 h-4 text-eco-500" /> Key Target Metric
              </div>
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                {sdg.targetFocus}
              </p>
            </div>

            <div className="mb-6">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                How EcoConnect Delivers Real Community Action
              </h4>
              <ul className="space-y-2.5">
                {sdg.keyTargets.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-200">
                    <CheckCircle className="w-4 h-4 text-eco-500 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
              <span className="text-xs text-slate-500">
                Verified Community Partnership
              </span>
              <a
                href={sdg.linkRoute}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-eco-600 hover:bg-eco-500 text-white font-semibold text-sm shadow-md shadow-eco-600/30 transition-all"
                onClick={() => setModalOpen(false)}
              >
                Join This Action <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
