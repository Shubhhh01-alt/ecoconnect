import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Sprout, 
  Send, 
  Heart, 
  CheckCircle2, 
  Globe, 
  ShieldCheck, 
  Trees, 
  UtensilsCrossed, 
  Droplet, 
  Trash2, 
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { useEco } from '../context/EcoContext';

export const Footer: React.FC = () => {
  const { stats, addNotification } = useEco();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubscribed(true);
    addNotification(`Subscribed ${email} to weekly EcoConnect Field Dispatch!`, 'success');
  };

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 pt-16 pb-12 mt-20 relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Top Newsletter & Impact Ribbon */}
        <div className="rounded-3xl bg-gradient-to-r from-emerald-900/60 to-slate-800/80 border border-emerald-500/30 p-6 sm:p-10 mb-16 shadow-2xl backdrop-blur-md">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-3">
                <Sparkles className="w-3.5 h-3.5" /> Weekly Climate Dispatch
              </div>
              <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight mb-2">
                Join 50,000+ Climate Champions
              </h3>
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                Receive curated local volunteering drives, verified environmental alerts, surplus food pickups, and policy updates directly in your inbox every Thursday.
              </p>
            </div>

            <div className="lg:col-span-5">
              {subscribed ? (
                <div className="flex items-center gap-3 p-4 rounded-2xl bg-emerald-800/40 border border-emerald-500/50 text-emerald-200">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400 flex-shrink-0" />
                  <div>
                    <div className="font-bold text-sm">You are on the dispatch list!</div>
                    <div className="text-xs text-emerald-300/80">Check your inbox for your welcome action guide.</div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2.5">
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="Enter your email address..."
                    required
                    className="flex-1 px-4 py-3 rounded-xl bg-slate-950/80 border border-slate-700 text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  />
                  <button
                    type="submit"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 transition-all hover:scale-105 active:scale-95"
                  >
                    <span>Subscribe</span>
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Main Footer Links & SDG Alignment */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-14">
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="inline-flex items-center gap-2.5 group">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 shadow-md">
                <Sprout className="w-5 h-5 text-slate-950" />
              </div>
              <span className="text-2xl font-black tracking-tight text-white">
                Eco<span className="text-emerald-400">Connect</span>
              </span>
            </Link>

            <p className="text-slate-400 text-sm leading-relaxed max-w-sm">
              An open, citizen-first civic environmental platform turning passive climate concern into tangible local action. Built for neighborhoods, NGOs, schools, and civic leaders.
            </p>

            {/* UN SDG Badges */}
            <div className="pt-2">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
                Aligned with UN Sustainable Development Goals
              </div>
              <div className="flex flex-wrap gap-2">
                <Link
                  to="/about"
                  className="px-2.5 py-1 rounded-lg text-xs font-bold text-white shadow-sm hover:scale-105 transition-transform"
                  style={{ backgroundColor: '#FD9D24' }}
                  title="SDG 11: Sustainable Cities and Communities"
                >
                  SDG 11
                </Link>
                <Link
                  to="/about"
                  className="px-2.5 py-1 rounded-lg text-xs font-bold text-white shadow-sm hover:scale-105 transition-transform"
                  style={{ backgroundColor: '#CF8D2A' }}
                  title="SDG 12: Responsible Consumption and Production"
                >
                  SDG 12
                </Link>
                <Link
                  to="/about"
                  className="px-2.5 py-1 rounded-lg text-xs font-bold text-white shadow-sm hover:scale-105 transition-transform"
                  style={{ backgroundColor: '#3F7E44' }}
                  title="SDG 13: Climate Action"
                >
                  SDG 13
                </Link>
                <Link
                  to="/about"
                  className="px-2.5 py-1 rounded-lg text-xs font-bold text-white shadow-sm hover:scale-105 transition-transform"
                  style={{ backgroundColor: '#56C02B' }}
                  title="SDG 15: Life on Land"
                >
                  SDG 15
                </Link>
              </div>
            </div>
          </div>

          {/* Action Hub */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4">
              Explore Initiatives
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/initiatives/tree-plantation" className="text-slate-400 hover:text-emerald-400 flex items-center gap-2 transition-colors">
                  <Trees className="w-3.5 h-3.5 text-emerald-500" /> Tree Plantation Drives
                </Link>
              </li>
              <li>
                <Link to="/initiatives/food-rescue" className="text-slate-400 hover:text-amber-400 flex items-center gap-2 transition-colors">
                  <UtensilsCrossed className="w-3.5 h-3.5 text-amber-500" /> Surplus Food Rescue
                </Link>
              </li>
              <li>
                <Link to="/initiatives/water-conservation" className="text-slate-400 hover:text-sky-400 flex items-center gap-2 transition-colors">
                  <Droplet className="w-3.5 h-3.5 text-sky-500" /> Water Conservation Hub
                </Link>
              </li>
              <li>
                <Link to="/initiatives/clean-up" className="text-slate-400 hover:text-teal-400 flex items-center gap-2 transition-colors">
                  <Trash2 className="w-3.5 h-3.5 text-teal-500" /> Clean-up Drives & Waste
                </Link>
              </li>
              <li>
                <Link to="/report" className="text-slate-400 hover:text-rose-400 flex items-center gap-2 transition-colors">
                  <ArrowRight className="w-3.5 h-3.5 text-rose-500" /> Report Environmental Hazard
                </Link>
              </li>
            </ul>
          </div>

          {/* Community & Action */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4">
              Community Action
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/events" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Upcoming Volunteering Drives
                </Link>
              </li>
              <li>
                <Link to="/community" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Eco-Champions Leaderboard
                </Link>
              </li>
              <li>
                <Link to="/community" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Community Action Stories
                </Link>
              </li>
              <li>
                <Link to="/impact" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Public Impact Dashboard
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Register as NGO Partner
                </Link>
              </li>
            </ul>
          </div>

          {/* About & Trust */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4">
              Governance & Info
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/about" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  About Our Mission
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  UN SDG Framework Mapping
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Corporate CSR Inquiries
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-slate-400 hover:text-emerald-400 transition-colors">
                  Help & FAQs
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Platform Stats & Copyright */}
        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-4 flex-wrap justify-center sm:justify-start">
            <span className="flex items-center gap-1 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              100% Green Hosted Infrastructure
            </span>
            <span>•</span>
            <span>{stats.treesPlanted.toLocaleString()} Trees Planted</span>
            <span>•</span>
            <span>{stats.mealsRescued.toLocaleString()} Meals Rescued</span>
          </div>

          <div className="flex items-center gap-1 text-slate-400">
            <span>Built with care for a sustainable planet</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
            <span>© {new Date().getFullYear()} EcoConnect</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
